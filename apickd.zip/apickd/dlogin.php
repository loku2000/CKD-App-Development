<?php
require_once('dbh.php');

// $d_id = "";
// $d_pass = "";

$d_id=$_GET['d_id'];
$d_pass=$_GET['d_pass'];

$loginqry = "SELECT * FROM doctor WHERE doctor_id = '$d_id' AND password = '$d_pass'";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$userObj = mysqli_fetch_assoc($qry); 
	$response['status'] = true;
	$response['message']= "Login Successfully";
	$response['data'] = $userObj;	
}
else{
	$response['status'] = false;
	$response['message']= "Login Failed";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>