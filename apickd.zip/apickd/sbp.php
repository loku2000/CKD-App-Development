<?php
require "conn.php";

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Fetch data based on patient_id in descending order of date
$patient_id = "your_patient_id"; // Replace 'your_patient_id' with the actual patient ID you want to fetch
$sql = "SELECT sbp, date FROM weekly WHERE patient_id = ? ORDER BY date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

// Check for errors
if (!$result) {
  die("Error executing query: " . mysqli_error($conn));
}

// Fetch results into an array
$data = array();
while ($row = $result->fetch_assoc()) {
  $data[] = $row;
}

// Close statement and connection
$stmt->close();
$conn->close();

// Return data as JSON
echo json_encode($data);
?>
