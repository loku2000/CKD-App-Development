<?php
// Replace with your actual database credentials
require("conn.php");

// Assuming data is sent via POST request as JSON
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Extract data from POST
    $patient_id = $_POST['patient_id'];

    // Prepare and execute the SQL query to retrieve data based on patient_id
    $sql = "SELECT creatine, potassium, haemoglobin, bicarbonate FROM monthly WHERE patient_id = '$patient_id'";
    $result = $conn->query($sql);

    if ($result) {
        // Check if any rows were returned
        if ($result->num_rows > 0) {
            // Fetch the data and store it in an array
            $data = array();
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }

            $response = array('success' => true, 'data' => $data);
            echo json_encode($response);
        } else {
            $response = array('success' => false, 'message' => 'No data found for the given patient ID');
            echo json_encode($response);
        }
    } else {
        $response = array('success' => false, 'message' => 'Error querying the database: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    $response = array('success' => false, 'message' => 'Invalid request method');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
