<?php
// Include the database connection configuration
include("dbh.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Assume doctor_id for comparison
        $doctor_id = $_POST['doctor_id'];

        // Check if other necessary fields are present for update
        if (isset($_POST['doctor_id']) && isset($_POST['name']) & isset($_POST['speciality']) & isset($_POST['gender'])) {
            $doctor_id = $_POST['doctor_id'];
            $name = $_POST['name'];
            $speciality = $_POST['speciality'];
            $gender = $_POST['gender'];
            $email = $_POST['email'];
    

            // Update data in d_profile table by doctor_id
            $updateDProfileSql = "UPDATE `d_profile` SET `doctor_id` = :doctor_id, `name` = :name, `speciality` = :speciality, `gender` = :gender, `email` = :email  WHERE `doctor_id` = :doctor_id";
            $stmtUpdateDProfile = $conn->prepare($updateDProfileSql);
            $stmtUpdateDProfile->bindParam(':doctor_id', $doctor_id, PDO::PARAM_STR);
            $stmtUpdateDProfile->bindParam(':name', $name, PDO::PARAM_STR);
            $stmtUpdateDProfile->bindParam(':speciality', $speciality, PDO::PARAM_STR);
            $stmtUpdateDProfile->bindParam(':gender', $gender, PDO::PARAM_STR);
            $stmtUpdateDProfile->bindParam(':email', $email, PDO::PARAM_STR);
           
            
            if ($stmtUpdateDProfile->execute()) {
                $response['success'] = true;
                $response['message'] = "Data updated successfully in 'd_profile' table";
            } else {
                $response['success'] = false;
                $response['message'] = "Error updating data in 'd_profile' table";
            }
        } else {
            $response['success'] = false;
            $response['message'] = "Required fields for update are missing";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid request method";
    }
} catch (PDOException $e) {
    // Handle any exceptions
    $response['success'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn = null;
?>
