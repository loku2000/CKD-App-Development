<?php
// Database connection details
require("conn.php");

// Directory where uploaded videos will be saved
$uploadDir = "videos/";

// Initialize an empty array to store video paths
$videos = array();

// Retrieve all video paths from the database
$sql = "SELECT * FROM video";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $videoPath = $row['video'];
        // Add the video path to the array
        $videos[] = $videoPath;
    }
} else {
    // No videos found
    $response = array(
        "status" => "error",
        "message" => "No videos found"
    );
    header('Content-Type: application/json');
    echo json_encode($response);
    exit; // Stop script execution
}

// Close the database connection
$conn->close();

// Send the JSON response
$response = array(
    "status" => "success",
    "videos" => $videos
);
header('Content-Type: application/json');
echo json_encode($response);
?>