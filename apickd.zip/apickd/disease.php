<?php
// Replace with your actual database credentials
require("conn.php");

// Function to get conditions for English and Tamil columns
function getConditions($english, $tamil) {
    $conditions = array();

    // Check for English column
    if ($english === 'yes') {
        $conditions[] = 'Earlier reading was considered a chore. I have read this book.. you should also read it.. there is this point in it.. there were many people who discussed it with their friends. But today we have to look for such people.';
    }

    // Check for Tamil column
    if ($tamil === 'yes') {
        $conditions[] = 'முன்பெல்லாம் வாசிப்பதை ஒரு வேள்வி போல கருதுவார்கள். நான் இந்த புத்தகம் படிச்சேன்.. நீங்களும் படிச்சுப் பாருங்க.. அதுல வர்ற இந்த பாயிண்ட் இருக்கே..என்று சிலாகித்து நண்பர்களுடன் விவாதிப்போர் அதிகம் இருந்தனர். ஆனால் இன்றோ அப்படிப்பட்டவர்களைத் தேடிப் பார்க்க வேண்டியுள்ளது.';
    }

    return $conditions;
}

// Assuming data is sent via POST request as JSON
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Extract data from POST
    $english = isset($_POST['english']) ? $_POST['english'] : '';
    $tamil = isset($_POST['tamil']) ? $_POST['tamil'] : '';

    // Get conditions for the provided values
    $conditions = getConditions($english, $tamil);

    // Print conditions in array format
    echo json_encode(array('success' => true, 'conditions' => $conditions));
} else {
    // Fetch conditions from the database (if needed)
    $result = $conn->query("SELECT * FROM disease");
    $conditionsArray = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Get conditions for each row
            $conditions = getConditions($row['english'], $row['tamil']);

            // Add conditions to the array
            $conditionsArray[] = array(
                'id' => $row['id'],
                'conditions' => $conditions
            );
        }
    }

    // Print conditions from the database in array format
    echo json_encode(array('success' => true, 'data' => $conditionsArray));
}

// Close the database connection
$conn->close();
?>
