<?php
// Database connection details
require("conn.php");

// Directory where uploaded images will be saved
$uploadDir = "images/";

// Initialize an empty array to store image paths
$images = array();

// Retrieve all image paths from the database
$sql = "SELECT * FROM image";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $imagePath = $row['image']; // Assuming 'image_path' is the correct column name in your database
        // Add the image path to the array
        $images[] = $imagePath;
    }
} else {
    // No images found
    $response = array(
        "status" => "error",
        "message" => "No images found"
    );
    header('Content-Type: application/json');
    echo json_encode($response);
    exit; // Stop script execution
}

// Close the database connection
$conn->close();

// Send the JSON response
$response = array(
    "status" => "success",
    "images" => $images
);
header('Content-Type: application/json');
echo json_encode($response);
?>
