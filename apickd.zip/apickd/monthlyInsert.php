<?php
// Replace with your actual database credentials
require("conn.php");

// Assuming data is sent via POST request as JSON
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Extract data from POST
    $patient_id = $_POST['patient_id'];
    $creatine = $_POST['creatine'];
    $potassium = $_POST['potassium'];
    $haemoglobin = $_POST['haemoglobin'];
    $bicarbonate = $_POST['bicarbonate'];
    $date = $_POST['date'];

    // Prepare and execute the SQL query
    $sql = "INSERT INTO monthly ( patient_id, creatine, potassium, haemoglobin, bicarbonate, date)
            VALUES ('$patient_id', '$creatine', '$potassium', '$haemoglobin', '$bicarbonate' , '$date')";

    if ($conn->query($sql) === TRUE) {
        $response = array('success' => true, 'message' => 'Data inserted successfully');
        echo json_encode($response);
    } else {
        $response = array('success' => false, 'message' => 'Error inserting data: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    $response = array('success' => false, 'message' => 'Invalid request method');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
