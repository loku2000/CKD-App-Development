<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$uploadDir = "images/";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "ckd");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Handle image upload
    $response = array();
    if (isset($_FILES["image"])) {
        // Check if the directory exists; if not, create it
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true); // Recursive directory creation
        }

        $fileName = $_FILES["image"]["name"];
        $tempName = $_FILES["image"]["tmp_name"];
        $folder = $uploadDir . $fileName; // Full path to the image file

        if (move_uploaded_file($tempName, $folder)) {
            // Generate password from the last four digits of the patient ID
            $patient_id = $_POST["patient_id"];
            $password = substr($patient_id, -4); // Get the last four digits of the patient ID

            // Prepare patient data
            $name = $_POST["name"];
            $age = $_POST["age"];
            $gender = $_POST["gender"];
            $mobile_number = $_POST["mobile_number"];
            $height = $_POST["height"];
            $weight = $_POST["weight"];
            $address = $_POST["address"];
            $date_of_joining = $_POST["date_of_joining"];

            // Save only the relative path in the database
            $relativeFolder = $uploadDir . $fileName;

            // Insert data into "addpatient" table
            $sqlAddPatient = "INSERT INTO addpatient (patient_id, name, age, gender, mobile_number, height, weight, address, date_of_joining, image) 
            VALUES ('$patient_id', '$name', '$age', '$gender', '$mobile_number', '$height', '$weight', '$address', '$date_of_joining', '$relativeFolder')";

            if ($conn->query($sqlAddPatient) === TRUE) {
                $response["status"] = "success";
                $response["message"] = "Patient information and image uploaded successfully.";

                // Insert data into "p_profile" table
                $sqlPProfile = "INSERT INTO p_profile (patient_id, name, age, gender, mobile_number, height, weight, address, date_of_joining, image) 
                VALUES ('$patient_id', '$name', '$age', '$gender', '$mobile_number', '$height', '$weight', '$address', '$date_of_joining', '$relativeFolder')";

                if ($conn->query($sqlPProfile) !== TRUE) {
                    $response["status"] = "error";
                    $response["message"] .= " Error inserting data into p_profile table: " . $conn->error;
                }

                // Insert data into "user" table with password
                $sqlUser = "INSERT INTO user (patient_id, password) VALUES ('$patient_id', '$password')";

                if ($conn->query($sqlUser) !== TRUE) {
                    $response["status"] = "error";
                    $response["message"] .= " Error inserting data into user table: " . $conn->error;
                }
            } else {
                $response["status"] = "error";
                $response["message"] = "Error inserting data into addpatient table: " . $conn->error;
            }
        } else {
            $response["status"] = "error";
            $response["message"] = "File upload failed.";
        }
    } else {
        $response["status"] = "error";
        $response["message"] = "No image file uploaded.";
    }

    $conn->close();
    echo json_encode($response);
} else {
    echo json_encode(array("status" => "error", "message" => "Invalid request."));
}
