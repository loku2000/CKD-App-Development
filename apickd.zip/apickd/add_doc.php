<?php
// Include the database connection configuration
include("dbh.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Get the data from the POST request
        $doctor_id = $_POST['doctor_id'];
        $name = $_POST['name'];
        $speciality = $_POST['speciality'];
        $gender = $_POST['gender'];

        // Extract the last 4 characters of doctor_id as password
        $password = substr($doctor_id, -4);

        // Insert data into d_profile table
        $insertDProfileSql = "INSERT INTO d_profile (doctor_id, name, speciality, gender) 
                              VALUES (:doctor_id, :name, :speciality, :gender)";
        $stmtInsertDProfile = $conn->prepare($insertDProfileSql);
        $stmtInsertDProfile->bindParam(':doctor_id', $doctor_id, PDO::PARAM_STR);
        $stmtInsertDProfile->bindParam(':name', $name, PDO::PARAM_STR);
        $stmtInsertDProfile->bindParam(':speciality', $speciality, PDO::PARAM_STR);
        $stmtInsertDProfile->bindParam(':gender', $gender, PDO::PARAM_STR);

        if ($stmtInsertDProfile->execute()) {
            // Insert data into doctor table
            $insertDoctorSql = "INSERT INTO doctor (doctor_id, password) 
                                VALUES (:doctor_id, :password)";
            $stmtInsertDoctor = $conn->prepare($insertDoctorSql);
            $stmtInsertDoctor->bindParam(':doctor_id', $doctor_id, PDO::PARAM_STR);
            $stmtInsertDoctor->bindParam(':password', $password, PDO::PARAM_STR);
            
            if ($stmtInsertDoctor->execute()) {
                $response['success'] = true;
                $response['message'] = "Data inserted successfully into 'd_profile' and 'doctor' table";
            } else {
                $response['success'] = false;
                $response['message'] = "Error inserting data into 'doctor' table";
            }
        } else {
            $response['success'] = false;
            $response['message'] = "Error inserting data into 'd_profile' table";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid request method";
    }
} catch (PDOException $e) {
    // Handle any exceptions
    $response['success'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn = null;
?>
