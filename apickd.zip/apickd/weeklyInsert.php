<?php
// Replace with your actual database credentials
require("conn.php");

// Assuming data is sent via POST request as JSON
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Extract data from POST

    $patient_id = $_POST['patient_id'];
    $sbp = $_POST['sbp'];
    $dbp = $_POST['dbp'];
    $urine_output = $_POST['urine_output'];
    $breathlessness = $_POST['breathlessness'];
    $pedaledema = $_POST['pedaledema'];
    $date = $_POST['date'];

    // Prepare and execute the SQL query
    $sql = "INSERT INTO weekly (patient_id, sbp, dbp, urine_output, breathlessness, pedaledema, date)
            VALUES ( '$patient_id', '$sbp', '$dbp', '$urine_output', '$breathlessness', '$pedaledema', '$date')";

    if ($conn->query($sql) === TRUE) {
        $response = array('success' => true, 'message' => 'Data inserted successfully');
        echo json_encode($response);
    } else {
        $response = array('success' => false, 'message' => 'Error inserting data: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    $response = array('success' => false, 'message' => 'Invalid request method');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
