<?php
// Include the database connection configuration
include("dbh.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Check if necessary fields are present for update
        if (isset($_POST['patient_id']) && isset($_POST['name']) && isset($_POST['age']) && isset($_POST['gender']) && isset($_POST['mobile_number']) && isset($_POST['height']) && isset($_POST['weight']) && isset($_POST['address']) && isset($_POST['date_of_joining']) && isset($_FILES['image'])) {
            $patient_id = $_POST['patient_id'];
            $name = $_POST['name'];
            $age = $_POST['age'];
            $gender = $_POST['gender'];
            $mobile_number = $_POST['mobile_number'];
            $height = $_POST['height'];
            $weight = $_POST['weight'];
            $address = $_POST['address'];
            $date_of_joining = $_POST['date_of_joining'];
            
            // Handle image upload
            $uploadDir = "image/";
            $uploadPath = $uploadDir . basename($_FILES["image"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($uploadPath, PATHINFO_EXTENSION));
            
            // Check if file was uploaded
            if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
                $response['success'] = false;
                $response['message'] = "File upload error.";
                exit(json_encode($response));
            }
            
            // Check if file already exists
            if (file_exists($uploadPath)) {
                $response['success'] = false;
                $response['message'] = "File already exists.";
                exit(json_encode($response));
            }

            // Check file size
            if ($_FILES["image"]["size"] > 500000) {
                $response['success'] = false;
                $response['message'] = "File is too large.";
                exit(json_encode($response));
            }

            // Allow certain file formats
            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                $response['success'] = false;
                $response['message'] = "Only JPG, JPEG, PNG & GIF files are allowed.";
                exit(json_encode($response));
            }

            // Move uploaded file to destination folder
            if (!move_uploaded_file($_FILES["image"]["tmp_name"], $uploadPath)) {
                $response['success'] = false;
                $response['message'] = "File upload failed.";
                exit(json_encode($response));
            }

            // Update data in p_profile table
            $updatePProfileSql = "UPDATE p_profile SET patient_id = :patient_id, name = :name, age = :age, gender = :gender, mobile_number = :mobile_number, height = :height, weight = :weight, address = :address, date_of_joining = :date_of_joining, image = :image WHERE patient_id = :patient_id";
            $stmtUpdatePProfile = $conn->prepare($updatePProfileSql);
            $stmtUpdatePProfile->bindParam(':patient_id', $patient_id, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':name', $name, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':age', $age, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':gender', $gender, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':mobile_number', $mobile_number, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':height', $height, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':weight', $weight, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':address', $address, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':date_of_joining', $date_of_joining, PDO::PARAM_STR);
            $stmtUpdatePProfile->bindParam(':image', $uploadPath, PDO::PARAM_STR);

            if ($stmtUpdatePProfile->execute()) {
                $response['success'] = true;
                $response['message'] = "Data updated successfully in 'p_profile' table.";
            } else {
                $response['success'] = false;
                $response['message'] = "Error updating data in 'p_profile' table.";
            }
        } else {
            $response['success'] = false;
            $response['message'] = "Required fields for update are missing.";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid request method.";
    }
} catch (PDOException $e) {
    // Handle any exceptions
    $response['success'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn = null;
?>
