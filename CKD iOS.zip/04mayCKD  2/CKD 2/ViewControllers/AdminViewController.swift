//
//  AdminViewController.swift
//  CKD
//
//  Created by SAIL on 12/12/23.
//

import UIKit

class AdminViewController: UIViewController {
    
    
    @IBOutlet weak var profileImage: UIImageView!
    
    
    @IBOutlet weak var subView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        profileImage.layer.cornerRadius = profileImage.frame.height / 2
        subView.clipsToBounds = true
        subView.layer.cornerRadius = 30
        subView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    }
    

   

}
