//
//  Iqkeyboard.swift
//  CKD
//
//  Created by SAIL on 06/04/24.
//

//import PackageDescription
//
//let package = Package(
//    name: "CKD",
//    products: [],
//    dependencies: [
//        .package(url: "https://github.com/hackiftekhar/IQKeyboardManager.git", from: "6.5.0")
//    ]
//)
