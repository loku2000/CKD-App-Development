//
//  Model.swift
//  CKD
//
//  Created by SAIL on 29/01/24.
//

import Foundation



struct DoctorLogin:Codable {
    var success:Bool
    var message:String
}

struct GetVideos:Codable {
    var status:String
    var videos:[String]
}

struct GetImages:Codable {
    var status:String
    var images:[String]
}

struct Disease:Codable {
    var success:Bool
    var conditions:[String]
}


struct AddPatient: Codable {
    let userPasswordUpdated, userInserted, addpatientInserted, pProfileInserted: Bool

    enum CodingKeys: String, CodingKey {
        case userPasswordUpdated = "user_password_updated"
        case userInserted = "user_inserted"
        case addpatientInserted = "addpatient_inserted"
        case pProfileInserted = "p_profile_inserted"
    }
}
struct PatientList: Codable {
    let status: String
    let data: [Datum]
}

struct Datum: Codable {
    let patientID, name, age : String
    let image: String

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case name, age,image
    }
}

struct DoctorProfile: Codable {
    let success: Bool
    let data: Doctordata
    let message: String
}

struct Doctordata: Codable {
    let sNo, doctorID, name, speciality,email : String
    let gender: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case doctorID = "doctor_id"
        case name, speciality, gender ,email
    }
}


struct PatientDetails: Codable {
    let data: DataClass
    let success: Bool
    let message: String
}

// MARK: - DataClass
struct DataClass: Codable {
    let sNo, patientID, name, age: String
    let gender, mobileNumber, height, weight: String
    let address, dateOfJoining, image : String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case patientID = "patient_id"
        case name, age, gender
        case mobileNumber = "mobile_number"
        case height, weight, address , image
        case dateOfJoining = "date_of_joining"
    }
}



struct WeeklyPrintData: Codable {
    let success: Bool
    let data: [WeeklyPrintDatas]
}

// MARK: - Datum
struct WeeklyPrintDatas: Codable {
    let sNo, patientID, sbp, dbp: String
    let urineOutput, breathlessness, pedaledema, date: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case patientID = "patient_id"
        case sbp, dbp
        case urineOutput = "urine_output"
        case breathlessness, pedaledema, date
    }
}



struct MonthlyPrintDatas: Codable {
    let success: Bool
    let data: [Alldata]
}

struct Alldata: Codable {
    let sNo, patientID, creatine, potassium: String
    let haemoglobin, bicarbonate, date: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case patientID = "patient_id"
        case creatine, potassium, haemoglobin, bicarbonate, date
    }
}
