//
//  UIView.swift
//  CKD
//
//  Created by SAIL on 27/01/24.
//

import UIKit
import UserNotifications

class PercentageProgressBarView: UIView {

    private let progressLayer = CAShapeLayer()
    private let percentageLabel = UILabel()
    private let shadowView = UIView()
    private let customLabel = UILabel()

    var progressBarColor: UIColor = .blue {
        didSet {
            progressLayer.strokeColor = progressBarColor.cgColor
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }

    private func setupView() {
        let lineWidth: CGFloat = 10
        let circularPath = UIBezierPath(arcCenter: CGPoint(x: bounds.midX, y: bounds.midY),
                                        radius: (min(bounds.width, bounds.height) - lineWidth) / 2,
                                        startAngle: -CGFloat.pi / 2,
                                        endAngle: 2 * CGFloat.pi - CGFloat.pi / 2,
                                        clockwise: true)
        progressLayer.path = circularPath.cgPath
        progressLayer.strokeColor = progressBarColor.cgColor
        progressLayer.fillColor = UIColor.clear.cgColor
        progressLayer.lineWidth = lineWidth
        progressLayer.lineCap = .round
        progressLayer.strokeEnd = 0
        layer.addSublayer(progressLayer)

        shadowView.frame = bounds
        shadowView.layer.shadowColor = UIColor.red.cgColor
        shadowView.layer.shadowOpacity = 0.8
        shadowView.layer.shadowRadius = 8
        addSubview(shadowView)

        percentageLabel.frame = bounds
        percentageLabel.textAlignment = .center
        percentageLabel.font = UIFont.systemFont(ofSize: 24)
        addSubview(percentageLabel)

        customLabel.frame = CGRect(x: 0, y: bounds.maxY + 5, width: bounds.width, height: 20)
        customLabel.textAlignment = .center
        customLabel.font = UIFont.systemFont(ofSize: 12)
        addSubview(customLabel)
    }

    func setPercentage(_ percentage: CGFloat, customText: String) {
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.duration = 1.0
        animation.fromValue = progressLayer.strokeEnd
        animation.toValue = percentage / 100
        animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        progressLayer.strokeEnd = percentage / 100
        progressLayer.add(animation, forKey: "percentageAnimation")

        percentageLabel.text = "\(Int(percentage))%"
        customLabel.text = customText
      }
    }
extension UIViewController {

    func checkBreath(value:Int,givenPen:Int) -> CGFloat {
        let givenPercentage = givenPen
        let correspondingValue = 100
        let valueToFind = value
        let x = (valueToFind * correspondingValue) / givenPercentage
        print("=======\(givenPen)======>\(x)")
        return CGFloat(x)
    }

    func drawBarChart(view:UIView,dataPoints: [String], values: [CGFloat]) {
           let barWidth: CGFloat = 30
           let spaceBetweenBars: CGFloat = 20
           let maxValue = values.max() ?? 100
           
           let yLabels: [String] = ["Normal", "Mild", "Moderate", "Severe"]
           
           // Define an array of colors corresponding to each yLabel
        let barColors: [UIColor] = [UIColor.normalColor ?? UIColor.red, UIColor.mildColor ?? UIColor.red, UIColor.orangeColor ?? UIColor.red, UIColor.severeColor ?? UIColor.red]
           
           for (index, value) in values.enumerated() {
               let barHeight = (value / maxValue) * view.frame.height
               
               let barX = CGFloat(index) * (barWidth + spaceBetweenBars)
               let barY = view.frame.height - barHeight
               
               let bar = UIBezierPath(roundedRect: CGRect(x: barX, y: barY, width: barWidth, height: barHeight),
                                      byRoundingCorners: [.topLeft, .topRight],
                                      cornerRadii: CGSize(width: 8, height: 8))
               
               let barLayer = CAShapeLayer()
               barLayer.path = bar.cgPath
               
               // Set the fillColor based on the corresponding category
               let colorIndex = yLabels.firstIndex(of: yLabels[scaledValue(value, maxValue: maxValue, count: yLabels.count)]) ?? 0
               barLayer.fillColor = barColors[colorIndex].cgColor
               
               // Check if the category is "Normal" and the value is at least 5%
               if yLabels[colorIndex] == "Normal" && (value / maxValue) * 100 >= 5 {
                   barLayer.fillColor = UIColor.green.cgColor // Change the color for "Normal" with at least 5%
               }
               
            view.layer.addSublayer(barLayer)
               
               // Optionally, add labels for data points
               let label = UILabel(frame: CGRect(x: barX, y: view.frame.height, width: barWidth, height: 20))
               label.text = dataPoints[index]
               label.textAlignment = .center
               label.textColor = .blue
               label.font = UIFont.systemFont(ofSize: 8)
               view.addSubview(label)
           }
       }
       
//       func scaledValue(_ value: CGFloat, maxValue: CGFloat, count: Int) -> Int {
//           let scaledValue = (value / maxValue) * CGFloat(count - 1)
//           return Int(round(scaledValue))
//       }

//    func drawBarChart1(view: UIView, dataPoints: [String], values: [CGFloat]) {
//        let barWidth: CGFloat = 30
//        let spaceBetweenBars: CGFloat = 40
//        let maxValue = values.max() ?? 100
//
//        let yLabels: [String] = ["Normal", "Mild", "Moderate", "Severe"]
//
//        let barColors: [UIColor] = [UIColor.normalColor ?? UIColor.red, UIColor.mildColor ?? UIColor.red, UIColor.orangeColor ?? UIColor.red, UIColor.severeColor ?? UIColor.red]
//
//        for (index, value) in values.enumerated() {
//            let barHeight = (value / maxValue) * view.frame.height
//
//            let barX = CGFloat(index) * (barWidth + spaceBetweenBars)
//            let barY = view.frame.height - barHeight
//
//            let bar = UIBezierPath(roundedRect: CGRect(x: barX, y: barY, width: barWidth, height: barHeight),
//                                   byRoundingCorners: [.topLeft, .topRight],
//                                   cornerRadii: CGSize(width: 8, height: 8))
//
//            let barLayer = CAShapeLayer()
//            barLayer.path = bar.cgPath
//
//            // Set the fillColor based on the corresponding category
//            var colorIndex: Int
//            if index == 0 {
//                // Apply special color treatment for the first index of cgFloatArray
//                if value <= 30 || value >= 70 {
//                    colorIndex = 3 // Severe color
//                } else {
//                    colorIndex = 0 // Normal color
//                }
//            } else {
//                // For other indices, use normal color selection logic
//                colorIndex = yLabels.firstIndex(of: yLabels[scaledValue(value, maxValue: maxValue, count: yLabels.count)]) ?? 0
//            }
//
//            barLayer.fillColor = barColors[colorIndex].cgColor
//
//            view.layer.addSublayer(barLayer)
//
//            // Optionally, add labels for data points
//            let label = UILabel(frame: CGRect(x: barX, y: view.frame.height, width: barWidth, height: 20))
//            label.text = dataPoints[index]
//            label.textAlignment = .center
//            label.textColor = UIColor.severeColor ?? UIColor.red
//            label.font = UIFont.systemFont(ofSize: 8)
//            view.addSubview(label)
//        }
//    }
    func drawBarChart1(view: UIView, dataPoints: [String], values: [CGFloat]) {
        let barWidth: CGFloat = 30
        let spaceBetweenBars: CGFloat = 40
        let maxValue = values.max() ?? 100

        let yLabels: [String] = ["Normal", "Mild", "Moderate", "Severe"]

        let barColors: [UIColor] = [UIColor.normalColor ?? UIColor.red, UIColor.mildColor ?? UIColor.red, UIColor.orangeColor ?? UIColor.red, UIColor.severeColor ?? UIColor.red]

        for (index, value) in values.enumerated() {
            let barHeight = (value / maxValue) * view.frame.height

            let barX = CGFloat(index) * (barWidth + spaceBetweenBars)
            let barY = view.frame.height - barHeight

            let bar = UIBezierPath(roundedRect: CGRect(x: barX, y: barY, width: barWidth, height: barHeight),
                                   byRoundingCorners: [.topLeft, .topRight],
                                   cornerRadii: CGSize(width: 8, height: 8))

            let barLayer = CAShapeLayer()
            barLayer.path = bar.cgPath

            // Set the fillColor based on the corresponding category
            var colorIndex: Int
            if index == 0 || (2 != 0) || (3 != 0)  {
                // Apply special color treatment for the first index of cgFloatArray
                if value <= 30 || value >= 70 {
                    colorIndex = 3 // Severe color
                } else {
                    colorIndex = 0 // Normal color
                }
            } else {
                // For other indices, use normal color selection logic
                colorIndex = yLabels.firstIndex(of: yLabels[scaledValue(value, maxValue: maxValue, count: yLabels.count)]) ?? 0
            }

            barLayer.fillColor = barColors[colorIndex].cgColor

            view.layer.addSublayer(barLayer)

            // Optionally, add labels for data points
            let label = UILabel(frame: CGRect(x: barX, y: view.frame.height, width: barWidth, height: 20))
            label.text = dataPoints[index]
            label.textAlignment = .center
            label.textColor = UIColor.severeColor ?? UIColor.red
            label.font = UIFont.systemFont(ofSize: 8)
            view.addSubview(label)
        }
    }
    func scaledValue(_ value: CGFloat, maxValue: CGFloat, count: Int) -> Int {
        guard maxValue != 0 && !value.isNaN && !maxValue.isNaN else {
           
            return 0 
        }

        let scaledValue = (value / maxValue) * CGFloat(count - 1)
        return Int(round(scaledValue))
    }
    
    
    func loadImage(url: String, imageView: UIImageView?) {
        
        
              
              let baseURL = ServiceAPI.baseURL
              
           
              guard let imageUrl = URL(string: baseURL + url) else {
                  return
              }
              
            
              let task = URLSession.shared.dataTask(with: imageUrl) { (data, response, error) in
                
                  guard error == nil, let imageData = data else {
                      print("Error downloading image: \(error?.localizedDescription ?? "Unknown error")")
                      return
                  }
                  
                 
                  DispatchQueue.main.async {
                      
                      if let image = UIImage(data: imageData) {
                          // Set the loaded image to the UIImageView
                          imageView?.image = image
                          
                      }
                  }
              }
              
              // Start the URL session task
              task.resume()
          }

}


class NotificationManager {
    static func scheduleNotification(at time: String, title: String, body: String, identifier: String) {
       let dateFormatter = DateFormatter()
       dateFormatter.dateFormat = "hh:mm a"

       guard let fireDate = dateFormatter.date(from: time) else {
           print("Invalid time format")
           return
       }

       let calendar = Calendar.current
       let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)

       let content = UNMutableNotificationContent()
       content.title = title
       content.body = body
       
       // Set the sound for the notification
     
        content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "tung-tung-3063.mp3"))
       // Create a weekly repeating trigger
       let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)

       let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)

       UNUserNotificationCenter.current().add(request) { (error) in
           if let error = error {
               print("Error scheduling notification: \(error.localizedDescription)")
           } else {
               print("Notification scheduled successfully")
           }
       }
   }
    
    static func withoutTimeNotification(at time: String? = nil, title: String, body: String, identifier: String) {
            let content = UNMutableNotificationContent()
            content.title = title
            content.body = body
            
            // Set the sound for the notification
            content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "tung-tung-3063.mp3"))
            
            var trigger: UNNotificationTrigger?
            
            if let time = time {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "hh:mm a"
                
                guard let fireDate = dateFormatter.date(from: time) else {
                    print("Invalid time format")
                    return
                }
                
                let calendar = Calendar.current
                let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)
                
                // Create a daily repeating trigger at the specified time
                trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
            } else {
                // Create an immediate trigger
                trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
            }
            
            guard let notificationTrigger = trigger else {
                print("Failed to create notification trigger")
                return
            }
            
            let request = UNNotificationRequest(identifier: identifier, content: content, trigger: notificationTrigger)
            
            UNUserNotificationCenter.current().add(request) { (error) in
                if let error = error {
                    print("Error scheduling notification: \(error.localizedDescription)")
                } else {
                    print("Notification scheduled successfully")
                }
            }
        }
}


extension UIColor {
   convenience init(hex: String, alpha: CGFloat = 1.0) {
       var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
       hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")

       var rgb: UInt64 = 0
    
       Scanner(string: hexSanitized).scanHexInt64(&rgb)
       let red = CGFloat((rgb & 0xFF0000) >> 16) / 255.0
       let green = CGFloat((rgb & 0x00FF00) >> 8) / 255.0
       let blue = CGFloat(rgb & 0x0000FF) / 255.0
       self.init(red: red, green: green, blue: blue, alpha: alpha)
   }
}
extension UITableViewCell {
    
    
    
    func drawBarChart2(view: UIView, dataPoint: String, value: CGFloat) {
        let barWidth: CGFloat = 30
        let spaceBetweenBars: CGFloat = 5
        let maxValue: CGFloat = 100 // Assuming a maximum value of 100

        let yLabels: [String] = ["Normal", "Mild", "Moderate", "Severe"]

        let barColors: [UIColor] = [UIColor.normalColor ?? UIColor.red, UIColor.mildColor ?? UIColor.red, UIColor.orangeColor ?? UIColor.red, UIColor.severeColor ?? UIColor.red]

        let barHeight = (value / maxValue) * view.frame.height

        let barX = (view.frame.width - barWidth) / 2 // Center the bar horizontally
        let barY = view.frame.height - barHeight

        let bar = UIBezierPath(roundedRect: CGRect(x: barX, y: barY, width: barWidth, height: barHeight),
                               byRoundingCorners: [.topLeft, .topRight],
                               cornerRadii: CGSize(width: 8, height: 8))

        let barLayer = CAShapeLayer()
        barLayer.path = bar.cgPath

        // Set the fillColor based on the corresponding category
        var colorIndex: Int
        if value <= 30 || value >= 70 {
            colorIndex = 3 // Severe color
        } else {
            colorIndex = 0 // Normal color
        }

        barLayer.fillColor = barColors[colorIndex].cgColor

        view.layer.addSublayer(barLayer)

        // Optionally, add labels for data points
        let label = UILabel(frame: CGRect(x: barX, y: view.frame.height, width: barWidth, height: 20))
        label.text = dataPoint // Use the single dataPoint value here
        label.textAlignment = .center
        label.textColor = UIColor.severeColor ?? UIColor.red
        label.font = UIFont.systemFont(ofSize: 8)
        view.addSubview(label)
    }


    
//    func drawBarChart2(view: UIView, dataPoints: [String], values: [CGFloat]) {
//        let barWidth: CGFloat = 30
//        let spaceBetweenBars: CGFloat = 5
//        let maxValue = values.max() ?? 100
//
//        let yLabels: [String] = ["Normal", "Mild", "Moderate", "Severe"]
//
//        let barColors: [UIColor] = [UIColor.normalColor ?? UIColor.red, UIColor.mildColor ?? UIColor.red, UIColor.orangeColor ?? UIColor.red, UIColor.severeColor ?? UIColor.red]
//
//        for (index, value) in values.enumerated() {
//            let barHeight = (value / maxValue) * view.frame.height
//
//            let barX = CGFloat(index) * (barWidth + spaceBetweenBars)
//            let barY = view.frame.height - barHeight
//
//            let bar = UIBezierPath(roundedRect: CGRect(x: barX, y: barY, width: barWidth, height: barHeight),
//                                   byRoundingCorners: [.topLeft, .topRight],
//                                   cornerRadii: CGSize(width: 8, height: 8))
//
//            let barLayer = CAShapeLayer()
//            barLayer.path = bar.cgPath
//
//            // Set the fillColor based on the corresponding category
//            var colorIndex: Int
//            if index == 0 || (2 != 0) || (3 != 0)  {
//                // Apply special color treatment for the first index of cgFloatArray
//                if value <= 30 || value >= 70 {
//                    colorIndex = 3 // Severe color
//                } else {
//                    colorIndex = 0 // Normal color
//                }
//            } else {
//                // For other indices, use normal color selection logic
//                colorIndex = yLabels.firstIndex(of: yLabels[scaledValue(value, maxValue: maxValue, count: yLabels.count)]) ?? 0
//            }
//
//            barLayer.fillColor = barColors[colorIndex].cgColor
//
//            view.layer.addSublayer(barLayer)
//
//            // Optionally, add labels for data points
//            let label = UILabel(frame: CGRect(x: barX, y: view.frame.height, width: barWidth, height: 20))
//            label.text = dataPoints[0]
//            label.textAlignment = .center
//            label.textColor = UIColor.severeColor ?? UIColor.red
//            label.font = UIFont.systemFont(ofSize: 8)
//            view.addSubview(label)
//        }
//    }
    func scaledValue(_ value: CGFloat, maxValue: CGFloat, count: Int) -> Int {
        guard maxValue != 0 && !value.isNaN && !maxValue.isNaN else {
            // Handle the case where maxValue is zero or either value or maxValue is NaN
            // For now, let's just return a default value or handle it according to your logic
            return 0 // or any default value you choose
        }

        let scaledValue = (value / maxValue) * CGFloat(count - 1)
        return Int(round(scaledValue))
    }
    
    
    func stringArrayToCGFloatArray(stringArray: [String]) -> [CGFloat]? {
        var cgFloatArray = [CGFloat]()
        
        for str in stringArray {
            if let floatValue = Float(str) {
                cgFloatArray.append(CGFloat(floatValue))
            } else {
                // Handle the case where the string couldn't be converted to a CGFloat
                return nil
            }
        }
        
        return cgFloatArray
    }
}


extension UIViewController {
    
    
    
    func scheduleNotifications(notificationData: [NotificationData]) {
       let dateFormatter = DateFormatter()
       dateFormatter.dateFormat = "hh:mm a"

       for data in notificationData {
           guard let fireDate = dateFormatter.date(from: data.time) else {
               print("Invalid time format for \(data.identifier)")
               continue
           }

           let calendar = Calendar.current
           let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)

           let content = UNMutableNotificationContent()
           content.title = data.title
           content.body = data.body
         //  content.sound = UNNotificationSound.default
           
           content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "Kindly%20take%20your%20Med.mp3"))

           let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)

           let request = UNNotificationRequest(identifier: data.identifier, content: content, trigger: trigger)

           UNUserNotificationCenter.current().add(request) { (error) in
               if let error = error {
                   print("Error scheduling notification for \(data.identifier): \(error.localizedDescription)")
               } else {
                   print("Notification scheduled successfully for \(data.identifier)")
               }
               
           }
           
           
       }
       
    }
}
