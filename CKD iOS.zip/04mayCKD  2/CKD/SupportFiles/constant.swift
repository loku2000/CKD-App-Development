//
//  constant.swift
//  CKD
//
//  Created by SAIL on 24/01/24.
//
import UIKit
import Foundation

struct ServiceAPI {
    
static let baseURL = "http://192.168.195.53/apickd/"
static let doctorLogInURL = baseURL+"doctor.php"
static let patientLogInURL = baseURL+"user.php"
static let addpatientURL = baseURL+"addpatient.php"
static let patientListURL = baseURL+"patientlist.php"
static let doctorProfileURL = baseURL+"d_profile.php"
static let doctorProfileUdateURL = baseURL+"d_profileupdate.php"
static let patientProfileURL = baseURL+"p_profile.php"
static let patientProfileUdateURL = baseURL+"p_profileupdate.php"
static let monthlyInsertURL = baseURL+"monthlyInsert.php"
static let weeklyInsertURL = baseURL+"weeklyInsert.php"
static let weeklyPrintURL = baseURL+"weeklyPrint.php"
static let monthlyPrintURL = baseURL+"monthlyPrint.php"
static let diseaseURL = baseURL+"disease.php"
static let getVideosUrl = baseURL+"vediosPrint.php"
static let getImageUrl = baseURL+"imagePrint.php"
    
}
extension UIColor {
    
    static let severeColor = UIColor(named: "FF0000")
    static let normalColor = UIColor(named: "32CD32")
    static let mildColor = UIColor(named: "6495ED")
    static let orangeColor = UIColor(named: "DAA06D")
    
}
