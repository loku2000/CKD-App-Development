//
//  ApiUrls.swift
//  CKD
//
//  Created by SAIL on 29/01/24.
//

import UIKit



struct ServiceAPI {

static let baseURL = "http://192.168.11.1/orthoflex_hip/"

static let doctorLoginURL = baseURL+"doctorlogin.php"
}
