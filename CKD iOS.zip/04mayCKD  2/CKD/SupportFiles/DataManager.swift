//
//  DataManager.swift
//  CKD
//
//  Created by SAIL on 29/01/24.
//

import UIKit
import Charts



class DataManager {
    
        static let shared = DataManager()
        
        private init() {
            // Private initialization to ensure just one instance is created.
        }
    var patientID = String()
    var doctorId = String()
    var joinDate = String()
    
    var sbPValue = [String]()
    var dbpValue = [String]()
    var urineValue = [String]()
    var breathlessness = [String]()
    var pedalemaValue = [String]()
    
    var creatine = [String]()
    var potassium = [String]()
    var haemoglobin = [String]()
    var bicarbonate = [String]()

    func sendMessage(title:String,message:String,navigation:UINavigationController) {
        let alertController = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        navigation.present(alertController, animated: false, completion: nil)
    }
//    func setupPieChart(view:PieChartView,sbp:Double,dpp:Double,breath:Double,urine:Double,pain:Double) {
//        view.chartDescription.enabled = false
//        view.drawHoleEnabled = false
//        view.rotationAngle = 0
//        //pieView.rotationEnabled = false
//        view.isUserInteractionEnabled = false
//       
//        
//        //pieView.legend.enabled = false
//        
//        var entries: [PieChartDataEntry] = Array()
//        entries.append(PieChartDataEntry(value: sbp, label: "sbp"))
//        entries.append(PieChartDataEntry(value: dpp, label: "dpp"))
//        entries.append(PieChartDataEntry(value: breath, label: "breath"))
//        entries.append(PieChartDataEntry(value: urine, label: "urine"))
//        entries.append(PieChartDataEntry(value: pain, label: "pedale"))
//        
//        let dataSet = PieChartDataSet(entries: entries, label: "")
//        
//        let c1 = NSUIColor(hex: 0xCD5C5C)
//        let c2 = NSUIColor(hex: 0xF08080)
//        let c3 = NSUIColor(hex: 0x40E0D0)
//        let c4 = NSUIColor(hex: 0x6495ED)
//        let c5 = NSUIColor(hex: 0xFFA07A)
//    
//        dataSet.colors = [c1, c2, c3, c4, c5]
//        dataSet.drawValuesEnabled = false
//        
//        view.data = PieChartData(dataSet: dataSet)
//    }
}

