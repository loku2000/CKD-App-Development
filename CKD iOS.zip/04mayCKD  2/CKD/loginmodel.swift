//
//  loginmodel.swift
//  CKD
//
//  Created by SAIL on 24/01/24.
//

import Foundation


struct Login:Codable {
   let success:Bool
   let message:String
}
