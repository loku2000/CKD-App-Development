//
//  PedaledemaImagesViewController.swift
//  CKD
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class PedaledemaImagesViewController: UIViewController {
    
    
    
    
    @IBOutlet weak var firstImage: UIImageView!
    
    @IBOutlet weak var secondImage: UIImageView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        allImageDetail()
    }
    
    
    func allImageDetail() {
        
        let formData = ["patient_id":DataManager.shared.patientID
                       
              ]
        
        APIHandler().postAPIValues(type: GetImages.self, apiUrl: ServiceAPI.getImageUrl , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.status == "success" {
                                self?.loadImage(url: data.images.first ?? "", images: self?.firstImage)
                                self?.loadImage(url: data.images.last ?? "", images: self?.secondImage)
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }
                    
          }

    }
    
    
    
    
    func loadImage(url:String,images:UIImageView?){
        
        
        let baseURL = ServiceAPI.baseURL
               
               // Convert the URL string to URL
               guard let imageUrl = URL(string: baseURL+url) else {
                   return
               }
               DispatchQueue.global().async {
                  
                   if let imageData = try? Data(contentsOf: imageUrl) {
                       // Convert the data to UIImage
                       if let image = UIImage(data: imageData) {
                           // Update UI on the main thread
                           DispatchQueue.main.async {
                               // Set the loaded image to the UIImageView
                            images?.image = image
                           }
                       }
                   }
    }
        
        
    }

    @IBAction func backTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
  
}
