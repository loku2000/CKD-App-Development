//
//  ProfileViewController.swift
//  CKD
//
//  Created by SAIL on 13/12/23.
//

import UIKit

class ProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    @IBOutlet weak var profileImage: UIImageView!
    
    
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet weak var nameView: UIView!
    
    @IBOutlet weak var contactView: UIView!
    
    @IBOutlet weak var nameField: UITextField!
    
    @IBOutlet weak var contactField: UITextField!
    
    @IBOutlet weak var mailView:
        UIView!
    
    @IBOutlet weak var mailField: UITextField!
    
    @IBOutlet weak var weightView: UIView!
    
    @IBOutlet weak var weightField: UITextField!
    
    @IBOutlet weak var heightView: UIView!
    
    @IBOutlet weak var heightField: UITextField!
    
    @IBOutlet weak var addressview: UIView!
    
    @IBOutlet weak var adressField: UITextField!
    
    
  
    
    var selectedImage = [UIImage]()
    var imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        saveBtn.layer.cornerRadius = 10
        // Do any additional setup after loading the view.
    }
    
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.tabBarController?.tabBar.isHidden = true
        
        
       
    }
    
    
//    func updateDoctorDetail() {
//
//        let formData = ["patient_id": DataManager.shared.patientID,
//                        "name":nameField.text ?? "",
//                        "mobile_number":contactField.text ?? "",
//                        "age":"5",
//                        "gender":"male",
//                        "height":heightField.text ?? "",
//                        "weight":weightField.text ?? "",
//                        "address":adressField.text ?? "",
//                        "date_of_joining": DataManager.shared.joinDate
//
//
//              ]
//
//        APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.patientProfileUdateURL , method: "POST", formData: formData) { [weak self] result in
//                     switch result {
//                     case .success(let data):
//                        print(data)
//                        DispatchQueue.main.async {
//                            if data.success == true {
//
//
//                                let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
//
//
//                        let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
//                                        self?.navigationController?.popViewController(animated: false)
//                                    })
//                            alertController.addAction(okAction)
//
//                        self?.present(alertController, animated: true, completion: nil)
//
//
//
//                            }else {
//                            if let navigation = self?.navigationController  {
//                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
//                            }
//                            }
//                        }
//                     case .failure(let error):
//                        print(error)
//                        DispatchQueue.main.async {
//                        if let navigation = self?.navigationController  {
//                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
//                        }
//                        }
//                     }
//
//          }
//
//    }

  
    @IBAction func updatePhotoTap(_ sender: Any) {
        presentImagePicker()
        
        
    }
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
        
        
    }
    
    @IBAction func saveTap(_ sender: Any) {
        
        if contactField.text ?? "" != "" && heightField.text ?? "" != "" && weightField.text ?? "" != "" && adressField.text ?? "" != "" {
            updatePatientDetails()
        }else {
            if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Message", message: "fill all the fileds", navigation: navigation)
            }
        }
    }
    
    
    
    func presentImagePicker() {
               let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
               alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
                   self.openCamera()
               }))
               alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
                   self.openGallery()
               }))
               alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
               present(alert, animated: true, completion: nil)
           }
    
    
    
    
    func openCamera() {
              if UIImagePickerController.isSourceTypeAvailable(.camera) {
                  imagePicker.sourceType = .camera
                  present(imagePicker, animated: true, completion: nil)
              } else {
                  print("Camera not available")
              }
          }
          
          func openGallery() {
              imagePicker.sourceType = .photoLibrary
              present(imagePicker, animated: true, completion: nil)
          }

          func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
                if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
                    profileImage.image = pickedImage
                    selectedImage.append(pickedImage)
                    
                   
                }
            picker.dismiss(animated: true, completion: nil)
            }
          func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
              picker.dismiss(animated: true, completion: nil)
          }
    
    
    func updatePatientDetails() {
           
        let apiURL = ServiceAPI.patientProfileUdateURL
           print("API URL:", apiURL)

           let boundary = UUID().uuidString
           var request = URLRequest(url: URL(string: apiURL)!)
           request.httpMethod = "POST"
           request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
           var body = Data()
        let formData = ["patient_id": DataManager.shared.patientID,
                        "name":nameField.text ?? "",
                        "mobile_number":contactField.text ?? "",
                        "age":"5",
                        "gender":"male",
                        "height":heightField.text ?? "",
                        "weight":weightField.text ?? "",
                        "address":adressField.text ?? "",
                        "date_of_joining": DataManager.shared.joinDate
                                      
                                       
              ]


           for (key, value) in formData {
               body.append(contentsOf: "--\(boundary)\r\n".utf8)
               body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
               body.append(contentsOf: "\(value)\r\n".utf8)
           }


           let fieldNames = ["image"]

           for (index, image) in selectedImage.enumerated() {
               let fieldName = fieldNames[index]

               let imageData = image.jpegData(compressionQuality: 0.8)!
               body.append(contentsOf: "--\(boundary)\r\n".utf8)
               body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
               body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
               body.append(contentsOf: imageData)
               body.append(contentsOf: "\r\n".utf8)


           }

           // Add closing boundary
           body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body

           request.httpBody = body

           let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
               if let error = error {
                   print("Error: \(error)")
                   // Handle the error, e.g., show an alert to the user
                   return
               }

               if let httpResponse = response as? HTTPURLResponse {
                   print("Status code: \(httpResponse.statusCode)")

                           if let data = data {
                                       if let responseData = String(data: data, encoding: .utf8) {
                                           if let jsonData = responseData.data(using: .utf8) {
                                               do {
                                                   if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                                       if let status = json["status"] as? String, let message = json["message"] as? String {
                                                        if status == "sucess" {
                                                            
                                                            let alertController = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
                                                    let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                                                     
                                                                })
                                                        alertController.addAction(okAction)
                                                                
                                                    self.present(alertController, animated: true, completion: nil)
                                                            
                                                            
                                                        }else {
                                                          
                                                            DispatchQueue.main.async {
                                                                if let nav = self.navigationController {
                                                                    DataManager.shared.sendMessage(title: "Message", message: message, navigation: nav)
                                                                }
                                                            }
                                                        }
                                                          
                                                       }
                                                   }
                                               } catch {
                                                   print("Error parsing JSON: \(error)")
                                               }
                                           }
                                       }

               }
           }

           
       }
        
        task.resume()
        
    }
    
}
















