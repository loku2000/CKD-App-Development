//
//  DoctorWeeklyProgressViewController.swift
//  CKD
//
//  Created by SAIL on 26/12/23.
//

import UIKit

class DoctorWeeklyProgressViewController: UIViewController, UITextFieldDelegate {
    
    
    

    @IBOutlet weak var dateTextfield : UITextField!
    
   
   

}
