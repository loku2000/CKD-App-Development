//
//  PatientdetailsViewController.swift
//  CKD
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class PatientdetailsViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var backTap: UIButton!
    
    
    @IBOutlet weak var weeklyProgressTable: UICollectionView!
    
    
    @IBOutlet weak var ageLbl: UILabel!
    @IBOutlet weak var monthlyProgressTable: UICollectionView!
    
    @IBOutlet weak var namelbl: UILabel!
    
    
    @IBOutlet weak var genderLbl: UILabel!
    var weeklyProgressData:WeeklyPrintData?
    var monthlyProgressData:MonthlyPrintDatas?
    
    
    var weelkly = ["SBP","PBP","Urine O/P","Breathlessness","Pedaledema"]
    var monthly = ["creatine","potassium","haemoglobin","bicarbonate"]
    
    var patientId = String()
    var name = String()
    var age = String()
    var image = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        namelbl.text = name
        ageLbl.text = age
        genderLbl.text = patientId
        loadImage(url: image, imageView: imageView)
        DataManager.shared.patientID = patientId
        
       let reg = UINib(nibName: "BargraphTextCollectionViewCell", bundle: nil)
        weeklyProgressTable.register(reg, forCellWithReuseIdentifier: "BargraphTextCollectionViewCell")
       
        monthlyProgressTable.register(reg, forCellWithReuseIdentifier: "BargraphTextCollectionViewCell")
        
        let flow = CustomVerticalFlowLayout()
        weeklyProgressTable.collectionViewLayout = flow
        monthlyProgressTable.collectionViewLayout = flow
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        weeklyData()
        monthlyData()
    }
    
    func weeklyData() {
     
        let formData = ["patient_id": patientId]
        APIHandler().postAPIValues(type: WeeklyPrintData.self, apiUrl: ServiceAPI.weeklyPrintURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.success == true {
                                self?.weeklyProgressData = data
                                if let monthlyData = self?.weeklyProgressData {
                                    let sbpValues = monthlyData.data.filter { $0.sbp != "" }.map { $0.sbp }
                                    DataManager.shared.sbPValue = sbpValues
                                }
                                if let monthlyData = self?.weeklyProgressData {
                                    let sbpValues = monthlyData.data.filter { $0.dbp != "" }.map { $0.dbp }
                                    DataManager.shared.dbpValue = sbpValues
                                }
                                if let monthlyData = self?.weeklyProgressData {
                                    let sbpValues = monthlyData.data.filter { $0.urineOutput != "" }.map { $0.urineOutput }
                                    DataManager.shared.urineValue = sbpValues
                                }
                                if let monthlyData = self?.weeklyProgressData {
                                    let sbpValues = monthlyData.data.filter { $0.breathlessness != "" }.map { $0.breathlessness }
                                    DataManager.shared.breathlessness = sbpValues
                                }
                                if let monthlyData = self?.weeklyProgressData {
                                    let sbpValues = monthlyData.data.filter { $0.pedaledema != "" }.map { $0.pedaledema }
                                    DataManager.shared.pedalemaValue = sbpValues
                                }
                                
                                self?.weeklyProgressTable.reloadData()
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "weeklyProgressData", message: "No data available  for this patient ", navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "weeklyProgressData", message: "No data available  for this patient ", navigation: navigation)
                        }
                        }
                     }
           }
    }

    func monthlyData() {
     
        let formData = ["patient_id": patientId]
        APIHandler().postAPIValues(type: MonthlyPrintDatas.self, apiUrl: ServiceAPI.monthlyPrintURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.success == true {
                                self?.monthlyProgressData = data
                                if let monthlyData = self?.monthlyProgressData {
                                    let cre = monthlyData.data.filter { $0.creatine != "" }.map { $0.creatine }
                                    DataManager.shared.creatine = cre
                                }
                                if let monthlyData = self?.monthlyProgressData {
                                    let cre = monthlyData.data.filter { $0.potassium != "" }.map { $0.potassium }
                                    DataManager.shared.potassium = cre
                                }
                                if let monthlyData = self?.monthlyProgressData {
                                    let cre = monthlyData.data.filter { $0.haemoglobin != "" }.map { $0.haemoglobin }
                                    DataManager.shared.haemoglobin = cre
                                }
                                if let monthlyData = self?.monthlyProgressData {
                                    let cre = monthlyData.data.filter { $0.bicarbonate != "" }.map { $0.bicarbonate }
                                    DataManager.shared.bicarbonate = cre
                                }
                              
                                self?.monthlyProgressTable.reloadData()
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "monthlyProgressData", message: "No data available  for this patient ", navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "monthlyProgressData", message: "No data available  for this patient ", navigation: navigation)
                        }
                        }
                     }
           }
    }
    @IBAction func monthlyTap(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "DoctorMonthlyProgressVc") as! DoctorMonthlyProgressVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func weeklyTap(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "DctrWeekRepostVC") as! DctrWeekRepostVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
 
}

extension PatientdetailsViewController: UICollectionViewDelegate,UICollectionViewDataSource {


func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
     if collectionView == weeklyProgressTable {
        return 1
       }else {
         return 1
      }
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "BargraphTextCollectionViewCell", for: indexPath) as! BargraphTextCollectionViewCell
        if collectionView == weeklyProgressTable {
            let val = self.weeklyProgressData?.data.last
          //  cell.mainView.layer.sublayers?.removeAll()
            
            //        self.drawBarChart(view: cell.mainView, dataPoints: weelkly, values:[
            //            checkBreath(value: Int(val?.sbp ?? "") ?? 0, givenPen: 280),
            //            checkBreath(value:  Int(val?.dbp ?? "") ?? 0, givenPen: 200),
            //            checkBreath(value:  Int(val?.urineOutput ?? "") ?? 0, givenPen: 4000),
            //            checkBreath(value: Int(val?.breathlessness ?? "") ?? 0, givenPen: 4),
            //            checkBreath(value:  Int(val?.pedaledema ?? "") ?? 0, givenPen: 3)])
            //         return cell
            //       }else {
            //        let val = self.monthlyProgressData?.data[indexPath.row]
            //        cell.mainView.layer.sublayers?.removeAll()
            //        self.drawBarChart1(view: cell.mainView, dataPoints: monthly, values:[
            //            checkBreath(value: Int(val?.creatine ?? "") ?? 0, givenPen: 20),
            //            checkBreath(value:  Int(val?.potassium ?? "") ?? 0, givenPen: 10),
            //            checkBreath(value: Int(val?.bicarbonate ?? "") ?? 0, givenPen: 40),
            //            checkBreath(value:  Int(val?.haemoglobin ?? "") ?? 0, givenPen: 20)])
            //         return cell
            //      }
            
            
            if Int(val?.sbp ?? "") ?? 0 > 160 || Int(val?.sbp ?? "") ?? 0 < 60 {
                
                cell.sbpText.textColor = .red
            }else {
                cell.sbpText.textColor = .black
            }
            
            if Int(val?.dbp ?? "") ?? 0 > 100 || Int(val?.dbp ?? "") ?? 0 < 40{
                
                cell.dbpText.textColor = .red
            }else {
                cell.dbpText.textColor = .black
            }
            
            if Int(val?.urineOutput ?? "") ?? 0 < 400 {
                
                cell.urineOutputText.textColor = .red
            }else {
                cell.urineOutputText.textColor = .black
            }
            
            if Int(val?.breathlessness ?? "") ?? 0 > 3 {
                
                cell.breathlessnessText.textColor = .red
            }else {
                cell.breathlessnessText.textColor = .black
            }
            
            if Int(val?.pedaledema ?? "") ?? 0 > 2 {
                
                cell.pedaledemaText.textColor = .red
            }else {
                cell.pedaledemaText.textColor = .black
            }
            cell.datelbl.text = val?.date
            cell.sbpText.text = val?.sbp
            cell.dbpText.text = val?.dbp
            cell.urineOutputText.text = val?.urineOutput
            cell.breathlessnessText.text = val?.breathlessness
            cell.pedaledemaText.text = val?.pedaledema
            // cell.mainView.layer.sublayers?.removeAll()
            //        self.drawBarChart(view: cell.mainView, dataPoints: weelkly, values:[
            //            checkBreath(value: Int(val?.sbp ?? "") ?? 0, givenPen: 280),
            //            checkBreath(value: Int(val?.dbp ?? "") ?? 0, givenPen: 200),
            //            checkBreath(value: Int(val?.urineOutput ?? "") ?? 0, givenPen: 4000),
            //            checkBreath(value: Int(val?.breathlessness ?? "") ?? 0, givenPen: 4),
            //            checkBreath(value: Int(val?.pedaledema ?? "") ?? 0, givenPen: 3)])
            //
            //         if checkBreath(value: Int(val?.sbp ?? "") ?? 0, givenPen: 280) < 21 || checkBreath(value: Int(val?.sbp ?? "") ?? 0, givenPen: 280) > 57  {
            //             NotificationManager.withoutTimeNotification(title: "Systolic B.P", body: "Contact doctor!", identifier: "21")
            //
            //         }
            //
            //         if checkBreath(value: Int(val?.dbp ?? "") ?? 0, givenPen: 200) < 20 || checkBreath(value: Int(val?.dbp ?? "") ?? 0, givenPen: 200) > 50  {
            //             NotificationManager.withoutTimeNotification(title: "Diastolic B.P", body: "Contact doctor!", identifier: "20")
            //
            //         }
            //         if checkBreath(value: Int(val?.urineOutput ?? "") ?? 0, givenPen: 4000) < 10 {
            //             NotificationManager.withoutTimeNotification(title: "Urine O/P", body: "Contact doctor!", identifier: "10")
            //
            //         }
            //         if checkBreath(value: Int(val?.breathlessness ?? "") ?? 0, givenPen: 4) > 3 {
            //             NotificationManager.withoutTimeNotification(title: "Breathlessness", body: "Contact doctor!", identifier: "3")
            //
            //         }
            //         if checkBreath(value: Int(val?.pedaledema ?? "") ?? 0, givenPen: 3) > 2 {
            //             NotificationManager.withoutTimeNotification(title: "Pedaledema", body: "Contact doctor!", identifier: "2")
            //
            //         }
            return cell
        }else {
            let val = self.monthlyProgressData?.data.last

            cell.text1.text = "creatine"
            cell.two2.text = "potassium"
            cell.three.text = "haemoglobin"
            cell.fourth.text = "bicarbonate"
            cell.fifth.text = ""
            
            cell.dbpText.text = val?.potassium
            cell.sbpText.text = val?.creatine
            cell.urineOutputText.text = val?.haemoglobin
            cell.breathlessnessText.text = val?.bicarbonate
            cell.pedaledemaText.text = ""
            cell.datelbl.text = ""
            cell.dateLbl.text = ""
            //        cell.mainView.layer.sublayers?.removeAll()
            //        self.drawBarChart1(view: cell.mainView, dataPoints: monthly, values:[
            //            checkBreath(value: Int(val?.creatine ?? "") ?? 0, givenPen: 20),
            //            checkBreath(value: Int(val?.potassium ?? "") ?? 0, givenPen: 10),
            //            checkBreath(value: Int(val?.haemoglobin ?? "") ?? 0, givenPen: 20),
            //            checkBreath(value: Int(val?.bicarbonate ?? "") ?? 0, givenPen: 40)])
            //
            //           if checkBreath(value: Int(val?.creatine ?? "") ?? 0, givenPen: 20) > 75  {
            //               NotificationManager.withoutTimeNotification(title: "creatine", body: "Contact doctor!", identifier: "75")
            //
            //           }
            //
            //           if checkBreath(value: Int(val?.potassium ?? "") ?? 0, givenPen: 10) < 30 || checkBreath(value: Int(val?.potassium ?? "") ?? 0, givenPen: 10) > 50  {
            //               NotificationManager.withoutTimeNotification(title: "Potassium", body: "Contact doctor!", identifier: "50")
            //
            //           }
            //           if checkBreath(value: Int(val?.haemoglobin ?? "") ?? 0, givenPen: 20) < 75 {
            //               NotificationManager.withoutTimeNotification(title: "haemoglobin", body: "Contact doctor!", identifier: "75")
            //
            //           }
            //           if checkBreath(value: Int(val?.bicarbonate ?? "") ?? 0, givenPen: 20) > 85 {
            //               NotificationManager.withoutTimeNotification(title: "bicarbonate", body: "Contact doctor!", identifier: "85")
            //
            //           }
            //
            return cell
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == weeklyProgressTable {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(identifier: "OverAllBarGraphViewController") as! OverAllBarGraphViewController
            vc.monthlyProgress = false
            vc.titleText = "Monthly progress data"
            self.navigationController?.pushViewController(vc, animated: true)
        }else {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(identifier: "OverAllBarGraphViewController") as! OverAllBarGraphViewController
            vc.monthlyProgress = true
            vc.titleText = "Weekly progress data"
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}




class CustomVerticalFlowLayout: UICollectionViewFlowLayout {
   override func prepare() {
       super.prepare()
       guard let collectionView = collectionView else { return }
       self.scrollDirection = .horizontal
       minimumLineSpacing = 5
       minimumInteritemSpacing = 5
       let availableWidth = collectionView.bounds.width - sectionInset.left - sectionInset.right - minimumInteritemSpacing
      // let cellWidth = (availableWidth - minimumInteritemSpacing) / 1.0
       itemSize = CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
   }
}








