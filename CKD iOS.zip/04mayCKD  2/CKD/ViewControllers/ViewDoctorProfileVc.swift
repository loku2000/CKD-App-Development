//
//  ViewDoctorProfileVc.swift
//  CKD
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class ViewDoctorProfileVc: UIViewController {
    

    @IBOutlet weak var doctorId: UILabel!
    @IBOutlet weak var doctorName: UILabel!
    @IBOutlet weak var speciality: UILabel!
    @IBOutlet weak var gender: UILabel!
    @IBOutlet weak var mail: UILabel!
    
    @IBOutlet weak var editProfileBtn: UIButton!
    @IBOutlet weak var logoutBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        editProfileBtn.layer.cornerRadius = 10
        logoutBtn.layer.cornerRadius = 10
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        doctroDeatils()
    }
    
    func doctroDeatils() {
        
        let formData = ["doctor_id": DataManager.shared.doctorId]
        
        APIHandler().postAPIValues(type: DoctorProfile.self, apiUrl: ServiceAPI.doctorProfileURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.success == true {
                                self?.doctorId.text = ": \(data.data.doctorID)"
                                self?.doctorName.text = ": \(data.data.name)"
                                self?.speciality.text = ": \(data.data.speciality)"
                                self?.gender.text = ": \(data.data.gender)"
                                self?.mail.text = ": \(data.data.email)"
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }
                    
          }

    }
    
    @IBAction func editTap(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "EditDoctorProfileViewController") as! EditDoctorProfileViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    
    @IBAction func logOutTApped(_ sender: Any) {
        
        
        DispatchQueue.main.async {
            let alertController = UIAlertController(title: "Alert", message: "Do you want to logout?", preferredStyle: .alert)
            
          
            let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
             let adminVC = self.storyboard?.instantiateViewController(identifier: "AdminViewController") as! AdminViewController
                
                // Reset the navigation stack with AdminViewController as the root
                if let navigationController = self.navigationController {
                    navigationController.setViewControllers([adminVC], animated: true)
                }
            })
            alertController.addAction(okAction)
            
         
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in
                // Handle Cancel button tap if needed
            })
            alertController.addAction(cancelAction)
            
            
            self.present(alertController, animated: true, completion: nil)
        }

    }
    
}





