//
//  DocTabBarVc.swift
//  CKD
//
//  Created by SAIL on 14/12/23.
//

import UIKit

class DocTabBarVc: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

  
    }
    

