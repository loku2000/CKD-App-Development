//
//  AdminViewController.swift
//  CKD
//
//  Created by SAIL on 12/12/23.
//

import UIKit
import UserNotifications

class AdminViewController: UIViewController {
    
    
    @IBOutlet weak var profileImage: UIImageView!
    
    
    @IBOutlet weak var subView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        profileImage.layer.cornerRadius = profileImage.frame.height / 2
        subView.clipsToBounds = true
        subView.layer.cornerRadius = 30
        subView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
//    UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (granted, error) in
//        if granted {
//            print("Notification authorization granted")
//            UNUserNotificationCenter.current().delegate = self // Set delegate
//        } else {
//            print("Notification authorization denied")
//        }
//    }
}


//func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
//    // Customize how the notification is presented in the foreground
//    completionHandler([.alert, .sound]) // Display an alert and play a sound
//}
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tabBarController?.tabBar.isHidden = true
    }
    

    @IBAction func doctorTapped(_ sender: Any) {
    
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "DoctorLoginController") as! DoctorLoginController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
    @IBAction func patientTapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "PatientLoginController") as! PatientLoginController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
}
