//
//  OverAllBarGraphViewController.swift
//  CKD
//
//  Created by SAIL on 26/03/24.
import UIKit

class OverAllBarGraphViewController: UIViewController {
    
    
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var tableviewOne: UITableView!
    
    
    @IBOutlet weak var tableView: UITableView!
    
    
    var selectedIndex = 0
    
    var titleText = String()
    
    var name = ["spb","dpb","urine","breathless","pedalema"]
    var nameValues = [DataManager.shared.sbPValue,DataManager.shared.dbpValue,DataManager.shared.urineValue,DataManager.shared.breathlessness,DataManager.shared.pedalemaValue]
    var monthlyP = ["creatine","potassium","haemoglobin","bicarbonate"]
    var monthlyPValues = [DataManager.shared.creatine,DataManager.shared.potassium,DataManager.shared.haemoglobin,DataManager.shared.bicarbonate]
    
  
    
    var monthlyProgress = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        titleLbl.text = titleText
       
       let cell = UINib(nibName: "ValueTableViewCell", bundle: nil)
      
        tableView.register(cell, forCellReuseIdentifier: "ValueTableViewCell")
        
        let cel = UINib(nibName: "DropDownCell", bundle: nil)
        tableviewOne.register(cel, forCellReuseIdentifier: "DropDownCell")
        
    }
    
    
    
    @IBAction func backTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
  
}

extension OverAllBarGraphViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tableviewOne {
            if !monthlyProgress {
                return nameValues[selectedIndex].count
            }else {
                return monthlyPValues[selectedIndex].count
            }
        }else {
            if !monthlyProgress {
                return name.count
            }else {
                return monthlyP.count
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tableviewOne {
            let cel = tableView.dequeueReusableCell(withIdentifier: "DropDownCell", for: indexPath) as! DropDownCell
            if !monthlyProgress {
                cel.weekLbl.text = "Week \(indexPath.row + 1):"
                cel.valueNameLbl.text = name[selectedIndex]
                let datas = nameValues[selectedIndex]
                cel.valueLbl.text = datas[indexPath.row]
            }else {
                cel.weekLbl.text = "Month \(indexPath.row + 1):"
                cel.valueNameLbl.text = monthlyP[selectedIndex]
                let datas = monthlyPValues[selectedIndex]
                
                cel.valueLbl.text = datas[indexPath.row]
            }
            return cel
        }else {
            let cel = tableView.dequeueReusableCell(withIdentifier: "ValueTableViewCell", for: indexPath) as! ValueTableViewCell
            if !monthlyProgress {
                cel.valuelbl.text = name[indexPath.row]
                return cel
            }else {
                cel.valuelbl.text = monthlyP[indexPath.row]
                return cel
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == tableviewOne {
            
          tableviewOne.isHidden = true
            self.tableView.isHidden = false
            
        }else {
           
            tableviewOne.isHidden = false
            self.tableView.isHidden = true
            selectedIndex = indexPath.row
            tableviewOne.reloadData()
        }
    }
    
}



