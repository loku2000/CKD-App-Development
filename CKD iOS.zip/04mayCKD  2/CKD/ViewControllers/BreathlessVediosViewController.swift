//
//  BreathlessVediosViewController.swift
//  CKD
//
//  Created by SAIL on 27/01/24.

import UIKit
import AVFoundation

class BreathlessVediosViewController: UIViewController {
    
    
    @IBOutlet weak var backTap: UIButton!
    
    
    @IBOutlet weak var mainView: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        allVideosDetail()
    }

    func allVideosDetail() {
        let formData = ["patient_id":DataManager.shared.patientID]
        APIHandler().postAPIValues(type: GetVideos.self, apiUrl: ServiceAPI.getVideosUrl , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.status == "success" {
                              
                                self?.playVideo(url: data.videos.last ?? "")
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }
                    
          }

    }
    
    
    func playVideo(url:String) {
        
        let baseURL = ServiceAPI.baseURL
        let videoURL = URL(string: baseURL+url)
        let player = AVPlayer(url: videoURL!)
        let playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = self.mainView.bounds
        self.mainView.layer.addSublayer(playerLayer)
        player.play()
    }
    
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    
    
}
