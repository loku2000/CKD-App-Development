//
//  ViewController.swift
//  CKD
//
//  Created by SAIL on 28/10/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var getStartedBtn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        getStartedBtn.layer.cornerRadius = 10
    }


    @IBAction func getStartedTapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "AdminViewController") as! AdminViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
}

