//
//  OpenPDFViewController.swift
//  CKD
//
//  Created by SAIL on 05/03/24.
//

import UIKit
import WebKit

class OpenPDFViewController: UIViewController {
    
    
    
    @IBOutlet weak var webView: WKWebView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
