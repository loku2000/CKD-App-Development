//
//  NotificationViewController.swift
//  CKD
//
//  Created by SAIL on 12/02/24.
//

import UIKit

class NotificationViewController: UIViewController {
    
    
    
    @IBOutlet weak var tableNotification: UITableView!
    
    var notificationArray = ["Take a medicine as per the remainder!","Please follow diet","If codition is severe consult doctor immediately",]
        
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
     
        tableNotification.delegate = self
        tableNotification.dataSource = self
        
        let cel = UINib(nibName: "NotificationCell", bundle: nil)
        tableNotification.register(cel, forCellReuseIdentifier: "NotificationCell")
        
    }
    

    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }

    

}

extension NotificationViewController: UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notificationArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationCell", for: indexPath) as! NotificationCell
        cell.notoficationlbl.text = notificationArray[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70.0
        
    }
    
}
