//
//  ViewPatientProfileVc.swift
//  CKD
//
//  Created by SAIL on 15/12/23.
//

import UIKit

class ViewPatientProfileVc: UIViewController {
    
    @IBOutlet weak var patientId: UILabel!
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var contactNumber: UILabel!
    
    @IBOutlet weak var mail: UILabel!
    
    @IBOutlet weak var height: UILabel!
    
    @IBOutlet weak var weight: UILabel!
    
    @IBOutlet weak var address: UILabel!
    
    @IBOutlet weak var date: UILabel!
    
    @IBOutlet weak var editBtn: UIButton!
    
    @IBOutlet weak var logoutBtn: UIButton!
    
    
    @IBOutlet weak var profileImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        profileImage.layer.cornerRadius = 40
        editBtn.layer.cornerRadius = 10
        logoutBtn.layer.cornerRadius = 10
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.tabBarController?.tabBar.isHidden = false
        
        patientDeatils()
    }
    
    
    

       
  
    
    func patientDeatils() {
        
        let formData = ["patient_id":  DataManager.shared.patientID]
        
        APIHandler().postAPIValues(type: PatientDetails.self, apiUrl: ServiceAPI.patientProfileURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.success == true {
                                self?.patientId.text = ": \(data.data.patientID)"
                                self?.name.text = ": \(data.data.name)"
                                self?.contactNumber.text = ": \(data.data.mobileNumber)"
                                self?.mail.text = ": \(data.data.sNo)"
                                self?.height.text = ": \(data.data.height)"
                                self?.weight.text = ": \(data.data.weight)"
                                self?.address.text = ": \(data.data.address)"
                                self?.date.text = ": \(data.data.dateOfJoining)"
                                self?.loadImage(url: data.data.image, imageView: self?.profileImage)
                                DataManager.shared.joinDate = "\(data.data.dateOfJoining)"
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }
                    
          }

    }

    

    @IBAction func editTap(_ sender: Any) {
        
        
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "ProfileViewController") as! ProfileViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func logoutTap(_ sender: Any) {
        
      
                   DispatchQueue.main.async {
                       let alertController = UIAlertController(title: "Alert", message: "Do you want to signout?", preferredStyle: .alert)
                       
                     
                       let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                        let adminVC = self.storyboard?.instantiateViewController(identifier: "AdminViewController") as! AdminViewController
                           
                           // Reset the navigation stack with AdminViewController as the root
                           if let navigationController = self.navigationController {
                               navigationController.setViewControllers([adminVC], animated: true)
                           }
                       })
                       alertController.addAction(okAction)
                       
                    
                       let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in
                           // Handle Cancel button tap if needed
                       })
                       alertController.addAction(cancelAction)
                       
                       
                       self.present(alertController, animated: true, completion: nil)
                   }

               

    }
    

}
