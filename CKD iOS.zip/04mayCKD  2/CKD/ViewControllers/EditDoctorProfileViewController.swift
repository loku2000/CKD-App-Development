//
//  EditDoctorProfileViewController.swift
//  CKD
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class EditDoctorProfileViewController: UIViewController {

    
    @IBOutlet weak var nameBtn: UITextField!
    
    @IBOutlet weak var specialityBtn: UITextField!
    
    @IBOutlet weak var numberBtn: UITextField!
    
    
    @IBOutlet weak var mailBTN: UITextField!
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var saveBtn: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        saveBtn.layer.cornerRadius = 10
        // Do any additional setup after loading the view.
    }
    
    
    func updateDoctorDetail() {
        
        let formData = ["doctor_id": DataManager.shared.doctorId,
                        "name":nameBtn.text ?? "",
                        "speciality":specialityBtn.text ?? "",
                        "gender":"male",
                        "email": mailBTN.text ?? ""
              ]
        
        APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.doctorProfileUdateURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.success == true {
                                let alertController = UIAlertController(title: "Message", message: "Data Updated Successfully", preferredStyle: .alert)
                                    
                                  
                        let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                            self?.navigationController?.popViewController(animated: false)
                                    })
                            alertController.addAction(okAction)
                                    
                        self?.present(alertController, animated: true, completion: nil)
                                
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }
                    
          }

    }
    
    @IBAction func saveBtn(_ sender: Any) {

        if nameBtn.text ?? "" != "" && specialityBtn.text ?? "" != "" && numberBtn.text ?? "" != "" && mailBTN.text ?? "" != "" {
        updateDoctorDetail()
        }else {
            
            if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Alert", message: "Fill all the empty fiedls", navigation: navigation)
            }
        }
        
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
        
    }
    

}
