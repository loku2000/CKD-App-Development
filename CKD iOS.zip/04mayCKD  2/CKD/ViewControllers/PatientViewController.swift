//
//  PatientViewController.swift
//  CKD
//
//  Created by SAIL on 24/01/24.
//

import UIKit
import UserNotifications



struct GraphArray: Codable {
    let sbp, dbp: String
    let urineOutput, breathlessness, pedaledema: String
    
}

class PatientViewController: UIViewController,UNUserNotificationCenterDelegate {

    
    
    @IBOutlet weak var weekltTable: UICollectionView!
    @IBOutlet weak var monthlyTable: UICollectionView!
    @IBOutlet weak var weeklyBtn: UIButton!
    
    var weeklyProgressData:WeeklyPrintData?
    var monthlyProgressData:MonthlyPrintDatas?
    var weelkly = ["Sbb","Pbb","Urine O/P","Breathlessness","Pedaledema"]
    var monthly = ["Creatine","Potassium","Haemoglobin","Bicarbonate"]
    var points:[CGFloat] = [10.0,20.0]
    var newAr:[GraphArray]?
    
    var firstIntakeNot = [NotificationData]()
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        weeklyData()
        monthlyData()
        
        weeklyBtn.layer.cornerRadius = 10

        let reg = UINib(nibName: "BargraphTextCollectionViewCell", bundle: nil)
        weekltTable.register(reg, forCellWithReuseIdentifier: "BargraphTextCollectionViewCell")

        monthlyTable.register(reg, forCellWithReuseIdentifier: "BargraphTextCollectionViewCell")
         
         let flow = CustomVerticalFlowLayout()
        weekltTable.collectionViewLayout = flow
        monthlyTable.collectionViewLayout = flow
        
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (granted, error) in
         if granted {
             print("Notification authorization granted")
             UNUserNotificationCenter.current().delegate = self // Set delegate
          } else {
             print("Notification authorization denied")
          }
        }
        
       
                        self.firstIntakeNot.append(NotificationData(time: "08:00 am", title:"Reminder!", body:"தயவுசெய்து மருந்து எடுத்துக் கொள்ளுங்கள்", identifier: "1"))
                        self.firstIntakeNot.append(NotificationData(time: "12:00 am", title:"Reminder!", body:"தயவுசெய்து மருந்து எடுத்துக் கொள்ளுங்கள்", identifier: "2"))
                        self.firstIntakeNot.append(NotificationData(time: "08:00 pm", title:"Reminder!", body:"தயவுசெய்து மருந்து எடுத்துக் கொள்ளுங்கள்", identifier: "3"))
               
                self.scheduleNotifications(notificationData: self.firstIntakeNot)
                self.firstIntakeNot.removeAll()
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.tabBarController?.tabBar.isHidden = false
        
     
    }
    
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        // Customize how the notification is presented in the foreground
        completionHandler([.alert, .sound]) // Display an alert and play a sound
    }
        
      

    func weeklyData() {
      ///  let id = UserDefaults.standard.value(forKey: "patientId")
        let formData = ["patient_id": DataManager.shared.patientID]
        APIHandler().postAPIValues(type: WeeklyPrintData.self, apiUrl: ServiceAPI.weeklyPrintURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.success == true {
                                self?.weeklyProgressData = data
                                if let monthlyData = self?.weeklyProgressData {
                                    let sbpValues = monthlyData.data.filter { $0.sbp != "" }.map { $0.sbp }
                                    DataManager.shared.sbPValue = sbpValues
                                }
                                if let monthlyData = self?.weeklyProgressData {
                                    let sbpValues = monthlyData.data.filter { $0.dbp != "" }.map { $0.dbp }
                                    DataManager.shared.dbpValue = sbpValues
                                }
                                if let monthlyData = self?.weeklyProgressData {
                                    let sbpValues = monthlyData.data.filter { $0.urineOutput != "" }.map { $0.urineOutput }
                                    DataManager.shared.urineValue = sbpValues
                                }
                                if let monthlyData = self?.weeklyProgressData {
                                    let sbpValues = monthlyData.data.filter { $0.breathlessness != "" }.map { $0.breathlessness }
                                    DataManager.shared.breathlessness = sbpValues
                                }
                                if let monthlyData = self?.weeklyProgressData {
                                    let sbpValues = monthlyData.data.filter { $0.pedaledema != "" }.map { $0.pedaledema }
                                    DataManager.shared.pedalemaValue = sbpValues
                                }
                                self?.weekltTable.reloadData()
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }
           }
             
    }
    
    
    
    func monthlyData() {
      //  let id = UserDefaults.standard.value(forKey: "patientId")
        let formData = ["patient_id": DataManager.shared.patientID]
        APIHandler().postAPIValues(type: MonthlyPrintDatas.self, apiUrl: ServiceAPI.monthlyPrintURL , method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    if data.success == true {
                        self?.monthlyProgressData = data
                        if let monthlyData = self?.monthlyProgressData {
                            let cre = monthlyData.data.filter { $0.creatine != "" }.map { $0.creatine }
                            DataManager.shared.creatine = cre
                        }
                        if let monthlyData = self?.monthlyProgressData {
                            let cre = monthlyData.data.filter { $0.potassium != "" }.map { $0.potassium }
                            DataManager.shared.potassium = cre
                        }
                        if let monthlyData = self?.monthlyProgressData {
                            let cre = monthlyData.data.filter { $0.haemoglobin != "" }.map { $0.haemoglobin }
                            DataManager.shared.haemoglobin = cre
                        }
                        if let monthlyData = self?.monthlyProgressData {
                            let cre = monthlyData.data.filter { $0.bicarbonate != "" }.map { $0.bicarbonate }
                            DataManager.shared.bicarbonate = cre
                        }
                        self?.monthlyTable.reloadData()
                    }else {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                        }
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    if let navigation = self?.navigationController  {
                        DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                    }
                }
            }
        }
    }

    @IBAction func weeklyProgressTab(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "WeeklyProgressViewController") as! WeeklyProgressViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
   
    @IBAction func tapNotification(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "NotificationViewController") as! NotificationViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
      
    }

    @IBAction func callTap(_ sender: Any) {
        let phoneNumber = "9751232064"
        if let url = URL(string: "tel://\(phoneNumber)") {
            UIApplication.shared.open(url)
        }
    }
    
}

extension PatientViewController: UICollectionViewDelegate,UICollectionViewDataSource {


func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
     if collectionView == weekltTable {
        return 1
       }else {
         return 1
      }
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
     let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "BargraphTextCollectionViewCell", for: indexPath) as! BargraphTextCollectionViewCell
        
     if collectionView == weekltTable {
        let val = self.weeklyProgressData?.data.last
         if Int(val?.sbp ?? "") ?? 0 > 160 || Int(val?.sbp ?? "") ?? 0 < 60{
             
             cell.sbpText.textColor = .red
         }else {
             cell.sbpText.textColor = .black
         }
         
         if Int(val?.dbp ?? "") ?? 0 > 100 || Int(val?.dbp ?? "") ?? 0 < 40{
             
             cell.dbpText.textColor = .red
         }else {
             cell.dbpText.textColor = .black
         }
         
         if Int(val?.urineOutput ?? "") ?? 0 < 400 {
             
             cell.urineOutputText.textColor = .red
         }else {
             cell.urineOutputText.textColor = .black
         }
         
         if Int(val?.breathlessness ?? "") ?? 0 > 3 {
             
             cell.breathlessnessText.textColor = .red
         }else {
             cell.breathlessnessText.textColor = .black
         }
         
         if Int(val?.pedaledema ?? "") ?? 0 > 2 {
             
             cell.pedaledemaText.textColor = .red
         }else {
             cell.pedaledemaText.textColor = .black
         }
         cell.datelbl.text = val?.date
         cell.sbpText.text = val?.sbp
         cell.dbpText.text = val?.dbp
         cell.urineOutputText.text = val?.urineOutput
         cell.breathlessnessText.text = val?.breathlessness
         cell.pedaledemaText.text = val?.pedaledema
      //  cell.mainView.layer.sublayers?.removeAll()
        self.drawBarChart(view: cell.mainView, dataPoints: weelkly, values:[
            checkBreath(value: Int(val?.sbp ?? "") ?? 0, givenPen: 280),
            checkBreath(value: Int(val?.dbp ?? "") ?? 0, givenPen: 200),
            checkBreath(value: Int(val?.urineOutput ?? "") ?? 0, givenPen: 4000),
            checkBreath(value: Int(val?.breathlessness ?? "") ?? 0, givenPen: 4),
            checkBreath(value: Int(val?.pedaledema ?? "") ?? 0, givenPen: 3)])
         
         if val?.sbp ?? "" < "60" ||  val?.sbp ?? "" > "160"  {
             NotificationManager.withoutTimeNotification(title: "Systolic B.P", body: "Contact doctor!", identifier: "21")

         }
         
         if val?.dbp ?? "" < "40" ||  val?.dbp ?? "" > "100"{
             NotificationManager.withoutTimeNotification(title: "Diastolic B.P", body: "Contact doctor!", identifier: "20")

         }
         if val?.urineOutput ?? "" < "400" {
             NotificationManager.withoutTimeNotification(title: "Urine O/P", body: "Contact doctor!", identifier: "10")

         }
         if val?.breathlessness ?? "" > "3" {
             NotificationManager.withoutTimeNotification(title: "Breathlessness", body: "Contact doctor!", identifier: "3")

         }
         if val?.pedaledema ?? "" > "1" || val?.pedaledema ?? "" < "1" {
             NotificationManager.withoutTimeNotification(title: "Pedaledema", body: "Contact doctor!", identifier: "2")
//
        }
         return cell
       }else {
        let val = self.monthlyProgressData?.data.last
       
            if Int(val?.creatine ?? "") ?? 0 > 20 {
                
                cell.sbpText.textColor = .red
            }else {
                cell.sbpText.textColor = .black
            }
            
            if Int(val?.potassium ?? "") ?? 0 > 5 || Int(val?.potassium ?? "") ?? 0 < 3{
                
                cell.dbpText.textColor = .red
            }else {
                cell.dbpText.textColor = .black
            }
            
            if Int(val?.haemoglobin ?? "") ?? 0 > 20 {
                
                cell.urineOutputText.textColor = .red
            }else {
                cell.urineOutputText.textColor = .black
            }
            
            if Int(val?.bicarbonate ?? "") ?? 0 > 40 {
                
                cell.breathlessnessText.textColor = .red
            }else {
                cell.breathlessnessText.textColor = .black
            }
            
         
           cell.text1.text = "Creatine"
           cell.two2.text = "Potassium"
           cell.three.text = "Haemoglobin"
           cell.fourth.text = "Bicarbonate"
           cell.fifth.text = ""
           
           cell.dbpText.text = val?.potassium
           cell.sbpText.text = val?.creatine
           cell.urineOutputText.text = val?.haemoglobin
           cell.breathlessnessText.text = val?.bicarbonate
           cell.pedaledemaText.text = ""
           cell.datelbl.text = ""
           cell.dateLbl.text = ""
           if val?.creatine ?? "" > "20"  {
               NotificationManager.withoutTimeNotification(title: "creatine", body: "Contact doctor!", identifier: "75")

           }
           
           if val?.potassium ?? "" > "5" || val?.potassium ?? "" < "3"  {
               NotificationManager.withoutTimeNotification(title: "Potassium", body: "Contact doctor!", identifier: "50")

           }
           if val?.haemoglobin ?? "" > "20" {
               NotificationManager.withoutTimeNotification(title: "haemoglobin", body: "Contact doctor!", identifier: "75")

           }
           if val?.bicarbonate ?? "" > "40" {
               NotificationManager.withoutTimeNotification(title: "bicarbonate", body: "Contact doctor!", identifier: "85")

           }
        return cell
      }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == weekltTable {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(identifier: "OverAllBarGraphViewController") as! OverAllBarGraphViewController
            vc.monthlyProgress = false
            vc.titleText = "Monthly progress data"
            self.navigationController?.pushViewController(vc, animated: true)
        }else {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(identifier: "OverAllBarGraphViewController") as! OverAllBarGraphViewController
            vc.monthlyProgress = true
            vc.titleText = "Weekly progress data"
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}



struct NotificationData {
    let time: String
    let title: String
    let body: String
    let identifier: String
}


