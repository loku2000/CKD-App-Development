//
//  InstructionViewController.swift
//  CKD
//
//  Created by SAIL on 23/01/24.
//

import UIKit

class InstructionViewController: UIViewController {
    
    
    @IBOutlet weak var firstView: UIView!
    
    @IBOutlet weak var secView: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        firstView.layer.cornerRadius = 10
        secView.layer.cornerRadius = 10
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.tabBarController?.tabBar.isHidden = false
    }
    

    @IBAction func diseaseBtnTap(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "DiseaseInformationViewController") as! DiseaseInformationViewController
        vc.dietCheck = false
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func dieatBtnTap(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "DiseaseInformationViewController") as! DiseaseInformationViewController
        vc.dietCheck = true
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    
    
}
