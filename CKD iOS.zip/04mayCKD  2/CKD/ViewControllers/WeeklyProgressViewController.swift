//
//  WeeklyProgressViewController.swift
//  CKD
//
//  Created by SAIL on 16/12/23.
//

import UIKit
import UserNotifications

class WeeklyProgressViewController: UIViewController,UITextFieldDelegate,UNUserNotificationCenterDelegate {
    
    
    @IBOutlet weak var breathlessNessLbl: UILabel!
    @IBOutlet weak var systolic: UITextField!
    @IBOutlet weak var diastolic: UITextField!
    @IBOutlet weak var urine: UITextField!
    @IBOutlet weak var dateLbl: UITextField!
    @IBOutlet weak var optionTable: UITableView!
    @IBOutlet weak var pedalEdemaBtn: UIButton!
    @IBOutlet weak var presentBtn: UIButton!
    @IBOutlet weak var absentBtn: UIButton!
    @IBOutlet weak var severeBtn: UIButton!
    @IBOutlet weak var submitBtn: UIButton!
    

    var array = ["1","2","3","4"]
    
    var breathlessNessCount = Int()
    
    var breathlessNess = ["No breathlessness except on strenuous exercise","Shortness of breath when hurryingon the level or walking up a slight hill","Walks slower than people of same age on the level because of breathlessness","tops for breath after walking 100 m or after few minutes on the level plane",]

    var pedaledema = String()
    var datePicker = UIDatePicker()

    override func viewDidLoad() {
        super.viewDidLoad()
        dateLbl.delegate = self
        
        let cel = UINib(nibName: "BreathOptionCell", bundle: nil)
        optionTable.register(cel, forCellReuseIdentifier: "cell")
        
        submitBtn.layer.cornerRadius = 10
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (granted, error) in
         if granted {
            print("Notification authorization granted")
            UNUserNotificationCenter.current().delegate = self // Set delegate
          } else {
            print("Notification authorization denied")
          }
       }
    }
 func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
   
    completionHandler([.alert, .sound]) 
  }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.tabBarController?.tabBar.isHidden = true
        optionTable.isHidden = true
    }

    @IBAction func pedalHelp(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "PedaledemaImagesViewController") as! PedaledemaImagesViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func patientWeeklyInsert() {

        let patientId = UserDefaults.standard.value(forKey: "patientId") ?? ""

        let formData = [ "s_no": "01",
                         "patient_id":DataManager.shared.patientID,
                        "sbp": systolic.text ?? "",
                        "dbp": diastolic.text ?? "",
                        "urine_output": urine.text ?? "",
                        "breathlessness":"\(breathlessNessCount)",
                        "pedaledema": "\(pedaledema)",
                        "date": dateLbl.text ?? "",
        ]

        APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.weeklyInsertURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.success == true {
                                if let navigation = self?.navigationController  {
                                    DataManager.shared.sendMessage(title: "Message", message: data.message, navigation: navigation)
                                    NotificationManager.scheduleNotification(at: "09.00 AM", title: "Remainder", body: "Please submit Weekly  data!", identifier: "1")
                                }
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: data.message, navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }

          }

    }
    
    func showDatePicker(){
      
        datePicker.datePickerMode = .date
        
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .inline
        }
        else {
            datePicker.preferredDatePickerStyle = .wheels
        }
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        
        //done button & cancel button
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
      
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
      
        toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
        
        
        self.dateLbl.inputAccessoryView = toolbar
        self.dateLbl.inputView = datePicker
      
    }
    @objc func cancelDatePicker(_ sender: UIButton){
        self.dateLbl.text? = ""
        self.view.endEditing(true)
    }

    @objc func donedatePicker(_ sender: UIButton){
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        self.dateLbl.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }

   func textFieldDidBeginEditing(_ textField: UITextField) {
       showDatePicker()
   }
    
    @IBAction func tapSelectHere(_ sender: Any) {
        optionTable.isHidden = false
        optionTable.reloadData()
    }
    
    @IBAction func absentTapped(_ sender: Any) {
      
        pedaledema = "0"
        absentBtn.setImage(UIImage(named: "select"), for: .normal)
        presentBtn.setImage(UIImage(named: "unselect"), for: .normal)
        severeBtn.setImage(UIImage(named: "unselect"), for: .normal)
    }
    
    @IBAction func presentTapped(_ sender: Any) {
       
        pedaledema = "1"
        absentBtn.setImage(UIImage(named: "unselect"), for: .normal)
        presentBtn.setImage(UIImage(named: "select"), for: .normal)
        severeBtn.setImage(UIImage(named: "unselect"), for: .normal)
    }
    
    
    @IBAction func severeTapped(_ sender: Any) {
       
        pedaledema = "2"
        absentBtn.setImage(UIImage(named: "unselect"), for: .normal)
        presentBtn.setImage(UIImage(named: "unselect"), for: .normal)
        severeBtn.setImage(UIImage(named: "select"), for: .normal)
    }
    
    
    @IBAction func submitTapped(_ sender: Any) {

        if systolic.text ?? "" != "" && diastolic.text ?? "" != "" && urine.text ?? "" != "" && dateLbl.text ?? "" != "" && pedaledema != "" && breathlessNessLbl.text ?? "" != "" {
            patientWeeklyInsert()
            
        }else {
            
            DispatchQueue.main.async {
            if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Alert", message: "Missing data", navigation: navigation)
            }
            }
        }
        
    }
    
    @IBAction func backTapped(_ sender: Any) {
    }
    
    
    @IBAction func breathLessTaped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "BreathlessVediosViewController") as! BreathlessVediosViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    @IBAction func backTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    
}

extension WeeklyProgressViewController:UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return breathlessNess.count
     }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BreathOptionCell
    cell.optionLbl.text = breathlessNess[indexPath.row]
    return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
     }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        breathlessNessLbl.text = breathlessNess[indexPath.row]
        breathlessNessCount = indexPath.row + 1
        optionTable.isHidden = true
    }
    
    
}
//class Notification {
//    static func scheduleNotification(at time: String, title: String, body: String, identifier: String) {
//       let dateFormatter = DateFormatter()
//       dateFormatter.dateFormat = "hh:mm a"
//
//       guard let fireDate = dateFormatter.date(from: time) else {
//           print("Invalid time format")
//           return
//       }
//
//       let calendar = Calendar.current
//       let dateComponents = calendar.dateComponents([.hour, .minute], from: fireDate)
//
//       let content = UNMutableNotificationContent()
//       content.title = title
//       content.body = body
//
//       // Set the sound for the notification
//       content.sound = UNNotificationSound.default
//
//       let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
//
//       let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
//
//       UNUserNotificationCenter.current().add(request) { (error) in
//           if let error = error {
//               print("Error scheduling notification: \(error.localizedDescription)")
//           } else {
//               print("Notification scheduled successfully")
//           }
//       }
//   }
//}
