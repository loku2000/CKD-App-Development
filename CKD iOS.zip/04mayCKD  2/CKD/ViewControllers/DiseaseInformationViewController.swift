//
//  DiseaseInformationViewController.swift
//  CKD
//
//  Created by SAIL on 23/01/24.
//

import UIKit
import WebKit

class DiseaseInformationViewController: UIViewController {
    
    
    @IBOutlet weak var webView: WKWebView!
    
    @IBOutlet weak var headerLbl: UILabel!
   
    
    @IBOutlet weak var tamilBtn: UIButton!
    
    @IBOutlet weak var enlishBtn: UIButton!
    
    var dietCheck = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
      
        self.openPDF(file:"CKDeng")
     
        if dietCheck {
            headerLbl.text = "Diet Information"
        }else {
            headerLbl.text = "Disease Information"
        }
      }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.tabBarController?.tabBar.isHidden = true
        
    }
    
    
    func openPDF(file:String) {
        let path = Bundle.main.path(forResource: file, ofType: "pdf")
        let url = URL(fileURLWithPath: path!)
        let request = URLRequest(url: url)
        webView.load(request)
    }
    
    
//    func informationOfPatient(eng:String,tamil:String) {
//        let id = UserDefaults.standard.value(forKey: "patientId")
//        var formData = [String: String]()
//
//        formData["english"] = eng
//        formData["tamil"] = tamil
//
//
//
//
//        APIHandler().postAPIValues(type: Disease.self, apiUrl: ServiceAPI.diseaseURL , method: "POST", formData: formData) { [weak self] result in
//                     switch result {
//                     case .success(let data):
//                        print(data)
//                        DispatchQueue.main.async {
//                            if data.success == true {
//                                self?.informationlabel.text = data.conditions.first
//                            }else {
//                                if let navigation = self?.navigationController  {
//                                    DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
//                                }
//
//
//                            }
//                        }
//                     case .failure(let error):
//                        print(error)
//                        DispatchQueue.main.async {
//                        if let navigation = self?.navigationController  {
//                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
//                        }
//                        }
//                     }
//
//
//    }
//
//    }
    

    @IBAction func englishTap(_ sender: Any) {
      
        enlishBtn.setImage(UIImage(named: "select"), for: .normal)
        tamilBtn.setImage(UIImage(named: "unselect"), for: .normal)
        
        self.openPDF(file: "CKDeng")
       

    }
   
     @IBAction func tamilTap(_ sender: Any) {
       
        tamilBtn.setImage(UIImage(named: "select"), for: .normal)
        enlishBtn.setImage(UIImage(named: "unselect"), for: .normal)
        self.openPDF(file: "CKD")

     }
     
    @IBAction func backTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    

}



