//
//  AddPatientViewController.swift
//  CKD
//
//  Created by SAIL on 16/12/23.
//

import UIKit
import Foundation

class AddPatientViewController: UIViewController ,UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var patientid: UITextField!
    
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var mobileNumber: UITextField!
    
    @IBOutlet weak var age: UITextField!
    
    @IBOutlet weak var gender: UITextField!
    
    @IBOutlet weak var height: UITextField!
    
    @IBOutlet weak var weight: UITextField!
    
    @IBOutlet weak var address: UITextField!
    
    @IBOutlet weak var dateOfJoining: UITextField!
    
    @IBOutlet weak var saveBtn: UIButton!
    
    
    var imagePicker = UIImagePickerController()
    var selectedImage = [UIImage]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        saveBtn.layer.cornerRadius = 10
        profileImage.layer.cornerRadius = 45
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.patientid.text = ""
        self.name.text = ""
        self.mobileNumber.text = ""
        self.age.text = ""
        self.gender.text = ""
        self.height.text = ""
        self.weight.text = ""
        self.address.text = ""
        self.dateOfJoining.text = ""
        self.profileImage.image = nil
    }
    

    func addPatient() {
        var formData = [String: String]()

        formData["patient_id"] = patientid.text ?? ""
        formData["name"] = name.text ?? ""
        formData["mobile_number"] = mobileNumber.text ?? ""
        formData["age"] = age.text ?? ""
        formData["gender"] = gender.text ?? ""
        formData["height"] = height.text ?? ""
        formData["weight"] = weight.text ?? ""
        formData["address"] = address.text ?? ""
        formData["date_of_joining"] = dateOfJoining.text ?? ""

           
        APIHandler().postAPIValues(type: AddPatient.self, apiUrl: ServiceAPI.addpatientURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.userInserted == true {
                                if let navigation = self?.navigationController  {
                                    DataManager.shared.sendMessage(title: "Message", message: "Added patient detail succesfully", navigation: navigation)
                                }
                            }else {
                                if let navigation = self?.navigationController  {
                                    DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                                }
                               
                               
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }
                    
            
    }
             
    }
    
    
    
    
    
    @IBAction func backTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func onSave(_ sender: Any) {
      //addPatient()
        addImageTobackEnd()
        
    }
    
    @IBAction func profileUpload(_ sender: Any) {
        
        presentImagePicker()
        
    }
    
    
    
    func presentImagePicker() {
               let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
               alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
                   self.openCamera()
               }))
               alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
                   self.openGallery()
               }))
               alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
               present(alert, animated: true, completion: nil)
           }
    
    
    
    
    func openCamera() {
              if UIImagePickerController.isSourceTypeAvailable(.camera) {
                  imagePicker.sourceType = .camera
                  present(imagePicker, animated: true, completion: nil)
              } else {
                  print("Camera not available")
              }
          }
          
          func openGallery() {
              imagePicker.sourceType = .photoLibrary
              present(imagePicker, animated: true, completion: nil)
          }

          func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
                if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
                    profileImage.image = pickedImage
                    selectedImage.append(pickedImage)
                    
                   
                }
            picker.dismiss(animated: true, completion: nil)
            }
          func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
              picker.dismiss(animated: true, completion: nil)
          }
    
    
    func addImageTobackEnd() {
           
        let apiURL = ServiceAPI.addpatientURL
           print("API URL:", apiURL)

           let boundary = UUID().uuidString
           var request = URLRequest(url: URL(string: apiURL)!)
           request.httpMethod = "POST"
           request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
           var body = Data()
        var formData = [String: String]()

        formData["patient_id"] = patientid.text ?? ""
        formData["name"] = name.text ?? ""
        formData["mobile_number"] = mobileNumber.text ?? ""
        formData["age"] = age.text ?? ""
        formData["gender"] = gender.text ?? ""
        formData["height"] = height.text ?? ""
        formData["weight"] = weight.text ?? ""
        formData["address"] = address.text ?? ""
        formData["date_of_joining"] = dateOfJoining.text ?? ""


           for (key, value) in formData {
               body.append(contentsOf: "--\(boundary)\r\n".utf8)
               body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
               body.append(contentsOf: "\(value)\r\n".utf8)
           }


           let fieldNames = ["image"]

           for (index, image) in selectedImage.enumerated() {
               let fieldName = fieldNames[index]

               let imageData = image.jpegData(compressionQuality: 0.8)!
               body.append(contentsOf: "--\(boundary)\r\n".utf8)
               body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
               body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
               body.append(contentsOf: imageData)
               body.append(contentsOf: "\r\n".utf8)


           }

           // Add closing boundary
           body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body

           request.httpBody = body

           let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
               if let error = error {
                   print("Error: \(error)")
                   // Handle the error, e.g., show an alert to the user
                   return
               }

               if let httpResponse = response as? HTTPURLResponse {
                   print("Status code: \(httpResponse.statusCode)")

                           if let data = data {
                                       if let responseData = String(data: data, encoding: .utf8) {
                                           if let jsonData = responseData.data(using: .utf8) {
                                               do {
                                                   if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                                       if let status = json["status"] as? String, let message = json["message"] as? String {
                                                        if status == "success" {
                                                            DispatchQueue.main.async {
                                                                
                                                                let alertController = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
                                                                
                                                                
                                                                let okAction = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction) in
                                                                    
                                                                    if let tab = self.tabBarController {
                                                                        tab.selectedIndex = 0
                                                                    }
                                                                }
                                                                
                                                                
                                                                
                                                                alertController.addAction(okAction)
                                                                
                                                                self.present(alertController, animated: true, completion: nil)
                                                                
                                                            }
                                                        }else {
                                                          
                                                            DispatchQueue.main.async {
                                                                if let nav = self.navigationController {
                                                                    DataManager.shared.sendMessage(title: "Message", message: message, navigation: nav)
                                                                }
                                                            }
                                                        }
                                                          
                                                       }
                                                   }
                                               } catch {
                                                   print("Error parsing JSON: \(error)")
                                               }
                                           }
                                       }

               }
           }

           
       }
        
        task.resume()
        
    }
}
