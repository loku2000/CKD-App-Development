//
//  DocHomeVc.swift
//  CKD
//
//  Created by SAIL on 14/12/23.
//

import UIKit

class DocHomeVc: UIViewController ,UITableViewDelegate, UITableViewDataSource {
    

    @IBOutlet weak var patientTable: UITableView!
       
          
    var patientListDetails:PatientList?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        patientTable.delegate = self
        patientTable.dataSource = self
        patientTable.register(UINib.init(nibName: "PatientListTVC", bundle: nil), forCellReuseIdentifier: "PatientListTVC")
        
        self.patientList()
    }
    
    func patientList() {
        let formData = [String: String]()
        APIHandler().postAPIValues(type: PatientList.self, apiUrl: ServiceAPI.patientListURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.status == "success" {
                            self?.patientListDetails = data
                                self?.patientTable.reloadData()
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }
                    
        }
             
    }
    @IBAction func viewAllBtn(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "PatientViewAllController") as! PatientViewAllController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    
}
extension DocHomeVc {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return min(self.patientListDetails?.data.count ?? 0, 5)
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PatientListTVC", for: indexPath) as! PatientListTVC
        cell.name.text = ": \(self.patientListDetails?.data[indexPath.row].name ?? "")"
        cell.age.text =  ": \(self.patientListDetails?.data[indexPath.row].age ?? "")"
        cell.gender.text = ": \(self.patientListDetails?.data[indexPath.row].patientID ?? "")"
        if let image = self.patientListDetails?.data[indexPath.row].image {
            self.loadImage(url: image, imageView: cell.ProfileImage)
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "PatientdetailsViewController") as! PatientdetailsViewController
        vc.patientId = self.patientListDetails?.data[indexPath.row].patientID ?? ""
        vc.name = self.patientListDetails?.data[indexPath.row].name ?? ""
        vc.age = self.patientListDetails?.data[indexPath.row].age ?? ""
        vc.image = self.patientListDetails?.data[indexPath.row].image ?? ""
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
