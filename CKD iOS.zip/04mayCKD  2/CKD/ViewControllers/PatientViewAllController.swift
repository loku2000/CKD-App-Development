import UIKit

class PatientViewAllController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var patientLists: [Datum] = []
    var filteredPatientListData: [Datum] = []
    
    var patientListDetails: PatientList? {
        didSet {
            guard let patientListDetails = patientListDetails else { return }
            patientLists = patientListDetails.data
            filteredPatientListData = patientLists // Initially showing all data
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        tableView.register(UINib(nibName: "PatientListTVC", bundle: nil), forCellReuseIdentifier: "PatientListTVC")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        patientList()
    }
    
    func patientList() {
        let formData: [String: String] = [:] // Adjust as needed
        
        APIHandler().postAPIValues(type: PatientList.self, apiUrl: ServiceAPI.patientListURL, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    if data.status == "success" {
                        self?.patientListDetails = data
                    } else {
                        if let navigation = self?.navigationController {
                            DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                        }
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    if let navigation = self?.navigationController {
                        DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                    }
                }
            }
        }
    }
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
}

extension PatientViewAllController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredPatientListData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PatientListTVC", for: indexPath) as! PatientListTVC
        let patient = filteredPatientListData[indexPath.row]
        cell.name.text = ": \(patient.name)"
        cell.age.text = ": \(patient.age)"
        cell.gender.text = ": \(patient.patientID)"
       
    self.loadImage(url: patient.image, imageView: cell.ProfileImage)
       
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "PatientdetailsViewController") as! PatientdetailsViewController
        let patient = filteredPatientListData[indexPath.row]
        DataManager.shared.patientID =  patient.patientID
        vc.patientId = patient.patientID
        vc.name = patient.name
        vc.age = patient.age
        vc.image = patient.image
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension PatientViewAllController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filterPatients(with: searchText)
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder() // Dismiss the keyboard when search button is clicked
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = "" // Clear the search bar text
        filterPatients(with: "")
        searchBar.resignFirstResponder() // Dismiss the keyboard when cancel button is clicked
    }
    
    private func filterPatients(with searchText: String) {
        if searchText.isEmpty {
            filteredPatientListData = patientLists
        } else {
            filteredPatientListData = patientLists.filter { $0.name.lowercased().contains(searchText.lowercased()) || $0.patientID.lowercased().contains(searchText.lowercased()) }
        }
        
        tableView.reloadData()
        
        if filteredPatientListData.isEmpty && !searchText.isEmpty {
            showAlert(message: "No matching patients found.")
        }
    }
    
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
}
