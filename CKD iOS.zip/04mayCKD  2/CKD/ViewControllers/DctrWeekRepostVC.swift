//
//  DctrWeekRepostVC.swift
//  CKD
//
//  Created by SAIL on 26/12/23.
//

import UIKit

class DctrWeekRepostVC: UIViewController,UITextFieldDelegate {
    
    
    
    @IBOutlet weak var table: UITableView!
    
    @IBOutlet weak var dateTextfield: UITextField!
    
    @IBOutlet weak var systolic: UITextField!
    
    
    @IBOutlet weak var diastolic: UITextField!
    
    
    @IBOutlet weak var urine: UITextField!
    
    
    @IBOutlet weak var breathLess: UILabel!
    
    @IBOutlet weak var absent: UIButton!
    
    
    @IBOutlet weak var severeBtn: UIButton!
    @IBOutlet weak var present: UIButton!
    
    var breathLessCount = Int()

    var breathlessNess = ["No breathlessness except on strenuous exercise","Shortness of breath when hurryingon the level or walking up a slight hill","Walks slower than people of same age on the level because of breathlessness","tops for breath after walking 100 m or after few minutes on the level plane",]

    let datePicker = UIDatePicker()
    var pedaledema = String()
    
    @IBOutlet weak var submitBtn: UIButton!
    
     override func viewDidLoad() {
         super.viewDidLoad()
         let cel = UINib(nibName: "BreathOptionCell", bundle: nil)
         table.register(cel, forCellReuseIdentifier: "cell")
         dateTextfield.delegate = self
        
        
        submitBtn.layer.cornerRadius = 10
     }
    
    
    func weeklyInsert() {

      

        let formData = [ "s_no": "01",
                         "patient_id": DataManager.shared.patientID,
                        "sbp": systolic.text ?? "",
                        "dbp": diastolic.text ?? "",
                        "urine_output": urine.text ?? "",
                        "breathlessness":"\(breathLessCount)",
                        "pedaledema": "\(pedaledema)",
                        "date": dateTextfield.text ?? "",
        ]

        APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.weeklyInsertURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.success == true {
                               
                                    
                                    
                                let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
                                        
                                      
                              let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                                            self?.navigationController?.popViewController(animated: false)
                                        })
                                alertController.addAction(okAction)
                                        
                               self?.present(alertController, animated: true, completion: nil)
                                    

                                
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: data.message, navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }

          }

    }
    
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
     
     func showDatePicker(){
         //Formate Date
         datePicker.datePickerMode = .date
         
         if #available(iOS 13.4, *) {
             datePicker.preferredDatePickerStyle = .inline
         }
         else {
             datePicker.preferredDatePickerStyle = .wheels
         }
         let toolbar = UIToolbar();
         toolbar.sizeToFit()
         
         //done button & cancel button
         let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
       
         let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
         
         let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
       
         toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
         
         
         self.dateTextfield.inputAccessoryView = toolbar
         self.dateTextfield.inputView = datePicker
       
     }
     @objc func cancelDatePicker(_ sender: UIButton){
         self.dateTextfield.text? = ""
         self.view.endEditing(true)
     }

     @objc func donedatePicker(_ sender: UIButton){
         
         let formatter = DateFormatter()
         formatter.dateFormat = "yyyy-MM-dd"
         self.dateTextfield.text = formatter.string(from: datePicker.date)
         self.view.endEditing(true)
     }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        showDatePicker()
    }
    
    @IBAction func breathLessTap(_ sender: Any) {
    }
    
    @IBAction func selectHere(_ sender: Any) {
        
        table.isHidden = false
    }
    
    
    @IBAction func absentTap(_ sender: Any) {
        pedaledema = "0"
        absent.setImage(UIImage(named: "select"), for: .normal)
        present.setImage(UIImage(named: "Unselect"), for: .normal)
        severeBtn.setImage(UIImage(named: "Unselect"), for: .normal)
    }
    
    
    
    @IBAction func presentTap(_ sender: Any) {
        pedaledema = "1"
        absent.setImage(UIImage(named: "Unselect"), for: .normal)
        present.setImage(UIImage(named: "select"), for: .normal)
        severeBtn.setImage(UIImage(named: "Unselect"), for: .normal)
    }
    
    
    @IBAction func severeTap(_ sender: Any) {
        pedaledema = "2"
        absent.setImage(UIImage(named: "Unselect"), for: .normal)
        present.setImage(UIImage(named: "Unselect"), for: .normal)
        severeBtn.setImage(UIImage(named: "select"), for: .normal)
    }
    
    
    @IBAction func submitTap(_ sender: Any) {
        
      
        if systolic.text ?? "" != "" && diastolic.text ?? "" != "" && urine.text ?? "" != "" && dateTextfield.text ?? "" != "" && pedaledema != "" && breathLess.text ?? "" != "" {
            weeklyInsert()
        }else {
            
            DispatchQueue.main.async {
            if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Alert", message: "Missing Data", navigation: navigation)
            }
            }
        }

    }
    
    
    
    
}




extension DctrWeekRepostVC:UITableViewDelegate,UITableViewDataSource {

   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return breathlessNess.count
     }

  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BreathOptionCell
    cell.optionLbl.text = breathlessNess[indexPath.row]
    return cell
  }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
     }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      breathLess.text = breathlessNess[indexPath.row]
      breathLessCount = indexPath.row + 1
     table.isHidden = true
    }


}




