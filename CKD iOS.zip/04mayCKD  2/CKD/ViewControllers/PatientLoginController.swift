//
//  PatientLoginController.swift
//  CKD
//
//  Created by SAIL on 16/12/23.
//

import UIKit

class PatientLoginController: UIViewController {
    
    @IBOutlet weak var patientId: UITextField!
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var profileImage: UIImageView!
    
    @IBOutlet weak var loginBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 30
        mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]

        loginBtn.layer.cornerRadius = 10
        profileImage.layer.cornerRadius = profileImage.frame.height / 2
    }
    
    
    
    func patientLogin() {
            
            
            let formData = ["patient_id": patientId.text ?? "",
                            "password": password.text ?? ""]
            
        APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.patientLogInURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.success == true {
                                UserDefaults.standard.setValue(self?.patientId.text ?? "", forKey: "patientId")
                                DataManager.shared.patientID = self?.patientId.text ?? ""
                                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                let vc = storyboard.instantiateViewController(identifier: "PatientTabbar") as! PatientTabbar
                                self?.navigationController?.pushViewController(vc, animated: true)
                            }else {
                                if let navigation = self?.navigationController  {
                                    DataManager.shared.sendMessage(title: "Alert", message: "Invalid Login", navigation: navigation)
                                }
                               
                               
                            }
                        }
                        
                   
                     case .failure(let error):
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }
                    
    }
             
    }
    

    @IBAction func loginTapped(_ sender: Any) {
        if patientId.text ?? "" != "" &&  password.text ?? "" != "" {
            patientLogin()
        }else {
            
            DispatchQueue.main.async {
            if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Alert", message: "Fill empty fields", navigation: navigation)
            }
            }
        }
        
        
        
        
    }
    
    @IBAction func backTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
}
