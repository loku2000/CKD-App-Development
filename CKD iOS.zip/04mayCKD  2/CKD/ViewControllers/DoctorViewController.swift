//
//  DoctorViewController.swift
//  CKD
//
//  Created by SAIL on 12/12/23.
//

import UIKit

class DoctorViewController: UIViewController {
    
    
    @IBOutlet weak var doctorProfile: UIImageView!
    
    
    @IBOutlet weak var emailView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        doctorProfile.layer.cornerRadius = doctorProfile.frame.height / 2
        emailView.clipsToBounds = true
        emailView.layer.cornerRadius = 30
        emailView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]

    
    }
    

}
