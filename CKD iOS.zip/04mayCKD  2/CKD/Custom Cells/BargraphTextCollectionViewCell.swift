//
//  BargraphTextCollectionViewCell.swift
//  CKD
//
//  Created by SAIL on 26/03/24.
//

import UIKit

class BargraphTextCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var fourth: UILabel!
    
    @IBOutlet weak var text1: UILabel!
   
    @IBOutlet weak var fifth: UILabel!
    
    @IBOutlet weak var two2: UILabel!
    
    @IBOutlet weak var sbpText: UILabel!
    
    @IBOutlet weak var three: UILabel!
    
    @IBOutlet weak var dbpText: UILabel!
    
    @IBOutlet weak var datelbl: UILabel!
    
    @IBOutlet weak var urineOutputText: UILabel!
    
    
    @IBOutlet weak var dateLbl: UILabel!
    
    @IBOutlet weak var breathlessnessText: UILabel!
    
    
    @IBOutlet weak var pedaledemaText: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    

}
