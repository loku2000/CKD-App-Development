//
//  CircleTableViewCell.swift
//  CKD
//
//  Created by SAIL on 27/01/24.
//

import UIKit

class CircleTableViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
