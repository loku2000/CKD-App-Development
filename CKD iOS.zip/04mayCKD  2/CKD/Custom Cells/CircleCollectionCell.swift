//
//  CircleCollectionCell.swift
//  CKD
//
//  Created by SAIL on 27/01/24.
//

import UIKit
import Charts

class CircleCollectionCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var mainView: UIView!
    
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
   
    
    
    
}




    
    

