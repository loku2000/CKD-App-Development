//
//  NotificationCell.swift
//  CKD
//
//  Created by SAIL on 24/02/24.
//

import UIKit

class NotificationCell: UITableViewCell {
    
    
    
    @IBOutlet weak var notoficationlbl: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    override func layoutSubviews() {
     super.layoutSubviews()
    
    let margin = UIEdgeInsets(top: 5, left: 1, bottom: 5, right: 1)
     contentView.frame = contentView.frame.inset(by: margin)
       contentView.layer.cornerRadius = 10
   }
}
