//
//  PatientListTVC.swift
//  CKD
//
//  Created by SAIL on 14/12/23.
//

import UIKit

class PatientListTVC: UITableViewCell {
    
    
    
    @IBOutlet weak var ProfileImage: UIImageView!
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var age: UILabel!
    
    @IBOutlet weak var gender: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
     super.layoutSubviews()
    
    let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
     contentView.frame = contentView.frame.inset(by: margin)
       contentView.layer.cornerRadius = 10
   }
}
