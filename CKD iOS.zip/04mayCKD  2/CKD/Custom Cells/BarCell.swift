//
//  BarCell.swift
//  CKD
//
//  Created by SAIL on 26/03/24.
//

import UIKit

class BarCell: UITableViewCell {
    
    
    
    @IBOutlet weak var headerlbl: UILabel!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    var allDataValues = [String]()
    var monthlyProgressdata = false
    
    
    var name = ["spb","dpb","urine","breathless","pedalema"]
    var monthlyP = ["creatine","potassium","haemoglobin","bicarbonate"]
    

    override func awakeFromNib() {
        super.awakeFromNib()
        collectionView.delegate = self
        collectionView.dataSource = self

        let cel =  UINib(nibName: "CircleCollectionCell", bundle: nil)
        collectionView.register(cel, forCellWithReuseIdentifier: "cell")
       self.collectionView.reloadData()
       
        
    }
    
  

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    
    override func layoutSubviews() {
     super.layoutSubviews()
    
    let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
     contentView.frame = contentView.frame.inset(by: margin)
       contentView.layer.cornerRadius = 10
       
   }
    func reloadDatas() {
      
           
        
        
    }
  
    
}
extension BarCell: UICollectionViewDelegate,UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
  
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if !monthlyProgressdata {
            switch self.collectionView.tag {
            case 0:
                return DataManager.shared.sbPValue.count
            case 1:
                return DataManager.shared.dbpValue.count
            case 2:
                return DataManager.shared.urineValue.count
            case 3:
                return DataManager.shared.breathlessness.count
            case 4:
                return DataManager.shared.pedalemaValue.count
            default:
                return 0
            }
        }else {
            
            switch self.collectionView.tag {
            case 0:
                return DataManager.shared.creatine.count
            case 1:
                return DataManager.shared.potassium.count
            case 2:
                return DataManager.shared.haemoglobin.count
            case 3:
                return DataManager.shared.bicarbonate.count
            default:
                return 0
            }
            
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cel = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CircleCollectionCell
        
     
        if !monthlyProgressdata {
            
            switch self.collectionView.tag {
            case 0:
                let stringArray = DataManager.shared.sbPValue
                if let cgFloatArray = stringArrayToCGFloatArray(stringArray: stringArray) {
                    print(cgFloatArray)
                    drawBarChart2(view: cel.mainView, dataPoint: "w", value: cgFloatArray[indexPath.item])
                } else {
                    print("Conversion failed. One or more strings couldn't be converted to CGFloat.")
                }
               
            case 1:
                let stringArray = DataManager.shared.dbpValue
                if let cgFloatArray = stringArrayToCGFloatArray(stringArray: stringArray) {
                    print(cgFloatArray)
                    drawBarChart2(view: cel.mainView, dataPoint: "w", value: cgFloatArray[indexPath.item])
                } else {
                    print("Conversion failed. One or more strings couldn't be converted to CGFloat.")
                }
                
            case 2:
                let stringArray = DataManager.shared.urineValue
                if let cgFloatArray = stringArrayToCGFloatArray(stringArray: stringArray) {
                    print(cgFloatArray)
                    drawBarChart2(view: cel.mainView, dataPoint: "w", value: cgFloatArray[indexPath.item])
                } else {
                    print("Conversion failed. One or more strings couldn't be converted to CGFloat.")
                }
                
            case 3:
                let stringArray = DataManager.shared.breathlessness
                if let cgFloatArray = stringArrayToCGFloatArray(stringArray: stringArray) {
                    print(cgFloatArray)
                    drawBarChart2(view: cel.mainView, dataPoint: "w", value: cgFloatArray[indexPath.item])
                } else {
                    print("Conversion failed. One or more strings couldn't be converted to CGFloat.")
                }
                
            case 4:
                let stringArray = DataManager.shared.pedalemaValue
                if let cgFloatArray = stringArrayToCGFloatArray(stringArray: stringArray) {
                    print(cgFloatArray)
                    drawBarChart2(view: cel.mainView, dataPoint: "w", value: cgFloatArray[indexPath.item])
                } else {
                    print("Conversion failed. One or more strings couldn't be converted to CGFloat.")
                }
                
            default:
                print("cellForRow error")
            }
            
            return cel
          
        } else {
           
           
            switch self.collectionView.tag {
                
            case 0:
                let stringArray = DataManager.shared.creatine
                if let cgFloatArray = stringArrayToCGFloatArray(stringArray: stringArray) {
                    print(cgFloatArray)
                    drawBarChart2(view: cel.mainView, dataPoint: "M", value: cgFloatArray[indexPath.item])
                } else {
                    print("Conversion failed. One or more strings couldn't be converted to CGFloat.")
                }
                
            case 1:
                let stringArray = DataManager.shared.potassium
                if let cgFloatArray = stringArrayToCGFloatArray(stringArray: stringArray) {
                    print(cgFloatArray)
                    drawBarChart2(view: cel.mainView, dataPoint: "M", value: cgFloatArray[indexPath.item])
                } else {
                    print("Conversion failed. One or more strings couldn't be converted to CGFloat.")
                }
                
            case 2:
               
                let stringArray = DataManager.shared.haemoglobin
                if let cgFloatArray = stringArrayToCGFloatArray(stringArray: stringArray) {
                    print(cgFloatArray)
                    drawBarChart2(view: cel.mainView, dataPoint: "M", value: cgFloatArray[indexPath.item])
                } else {
                    print("Conversion failed. One or more strings couldn't be converted to CGFloat.")
                }
                
            case 3:
                
                let stringArray = DataManager.shared.bicarbonate
                if let cgFloatArray = stringArrayToCGFloatArray(stringArray: stringArray) {
                    print(cgFloatArray)
                    drawBarChart2(view: cel.mainView, dataPoint:"M", value: cgFloatArray[indexPath.item])
                } else {
                    print("Conversion failed. One or more strings couldn't be converted to CGFloat.")
                }
                
            default:
                print("")
            }
        }
        
       return cel
    }
    
    
   
    
}

