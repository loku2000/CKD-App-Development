//
//  DoctorMonthlyProgressVc.swift
//  CKD
//
//  Created by SAIL on 18/12/23.
//

import UIKit

class DoctorMonthlyProgressVc: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var DateTEXTFEILD: UITextField!
    
    @IBOutlet weak var backTap: UIButton!
    
    
    
    @IBOutlet weak var creatine: UITextField!
    
    
    @IBOutlet weak var potassium: UITextField!
    
    
    @IBOutlet weak var bicarbonate: UITextField!
    
    
    @IBOutlet weak var haemoglobin: UITextField!
    
    
    @IBOutlet weak var submitBtn: UIButton!
    
    
    
    
    
    
    let datePicker = UIDatePicker()
//        let calendar = Calendar.current
//        let currentDate = Date()
    override func viewDidLoad() {
        super.viewDidLoad()

        DateTEXTFEILD.delegate = self
        submitBtn.layer.cornerRadius = 10
        
    }
    func monthlyInsert() {
        
       
        
        let formData = ["s_no": "01",
                        "patient_id":DataManager.shared.patientID,
                        "creatine": creatine.text ?? "",
                        "potassium": potassium.text ?? "",
                        "haemoglobin": haemoglobin.text ?? "",
                        "bicarbonate": bicarbonate.text ?? "",
                        "date": DateTEXTFEILD.text ?? "",
        ]
        
        APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.monthlyInsertURL , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.success == true {
                                
                                
                                let alertController = UIAlertController(title: "Message", message: data.message, preferredStyle: .alert)
                                    
                                  
                        let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in
                                        self?.navigationController?.popViewController(animated: false)
                                    })
                            alertController.addAction(okAction)
                                    
                        self?.present(alertController, animated: true, completion: nil)
                                

                             
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: data.message, navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }
                    
          }

    }

    
    
    
    
    
    
    
    func showDatePicker() {
           //Formate Date
           datePicker.datePickerMode = .date
           
           if #available(iOS 13.4, *) {
               datePicker.preferredDatePickerStyle = .inline
           }
           else {
               datePicker.preferredDatePickerStyle = .wheels
           }
           let toolbar = UIToolbar();
           toolbar.sizeToFit()
           
           //done button & cancel button
           let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
        
           let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
           
           let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
        
           toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
           
           
           self.DateTEXTFEILD.inputAccessoryView = toolbar
           self.DateTEXTFEILD.inputView = datePicker
         
       }
       @objc func cancelDatePicker(_ sender: UIButton){
           self.DateTEXTFEILD.text? = ""
           self.view.endEditing(true)
       }

       @objc func donedatePicker(_ sender: UIButton){
           
           let formatter = DateFormatter()
           formatter.dateFormat = "yyyy-MM-dd"
           self.DateTEXTFEILD.text = formatter.string(from: datePicker.date)
           self.view.endEditing(true)
       }

    func textFieldDidBeginEditing(_ textField: UITextField) {
     showDatePicker()
    }
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    
    @IBAction func submitTap(_ sender: Any) {
        
        if creatine.text ?? "" != "" && potassium.text ?? "" != "" && haemoglobin.text ?? "" != "" && bicarbonate.text ?? "" != "" && DateTEXTFEILD.text ?? ""  != ""{
            monthlyInsert()
        }else {
            DispatchQueue.main.async {
                if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Alert", message: "Missing Data", navigation: navigation)
            }
            }
        }
       
        
    }
    
    
    
    
}








