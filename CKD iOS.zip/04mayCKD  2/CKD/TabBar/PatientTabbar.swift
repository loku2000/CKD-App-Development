//
//  PatientTabbar.swift
//  CKD
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class PatientTabbar: UITabBarController {
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    


}
